﻿// Kybernetik // Copyright 2017 Kybernetik //

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace Kybernetik
{
    /// <summary>
    /// Indicates that a type can depend on other objects.
    /// Used by <see cref="Utils.TopologicalSort{T}(IEnumerable{T}, IEnumerable{IDependant{T}}, IEqualityComparer{T}, bool)"/>.
    /// </summary>
    public interface IDependant<T>
    {
        /// <summary>Everything that this object is dependant on. Return null if there are none.</summary>
        IEnumerable<T> Dependencies { get; }
    }

    /************************************************************************************************************************/

    /// <summary>
    /// Indicates that a member depends on a type (or types).
    /// Used by <see cref="Utils.TopologicalSort(IEnumerable{Type}, bool)"/>.
    /// </summary>
    [AttributeUsage(AttributeTargets.All)]
    public sealed class TypeDependencyAttribute : Attribute, IDependant<Type>
    {
        /************************************************************************************************************************/

        /// <summary>The types which the attributed member is dependant on.</summary>
        public readonly Type[] Dependencies;

        IEnumerable<Type> IDependant<Type>.Dependencies { get { return Dependencies; } }

        /************************************************************************************************************************/

        /// <summary>Constructs a new <see cref="TypeDependencyAttribute"/> with the specified dependencies.</summary>
        public TypeDependencyAttribute(params Type[] dependencies)
        {
            Dependencies = dependencies;
        }

        /************************************************************************************************************************/

        /// <summary>Gets the types which the specified member is dependant on (if any).</summary>
        public static Type[] GetDependencies(MemberInfo dependant)
        {
            Attribute attribute = GetCustomAttribute(dependant, typeof(TypeDependencyAttribute));
            if (attribute != null)
                return ((TypeDependencyAttribute)attribute).Dependencies;
            else
                return null;
        }

        /// <summary>Gets the types which the specified object is dependant on based on its type (if any).</summary>
        public static Type[] GetDependencies(object dependant)
        {
            if (dependant != null)
                return GetDependencies(dependant.GetType());
            else
                return null;
        }

        /************************************************************************************************************************/

        /// <summary>Checks if 'dependant' is dependant on 'dependency'.</summary>
        public static bool HasDependency(Type dependant, Type dependency)
        {
            Type[] dependencies = GetDependencies(dependant);
            if (dependencies != null)
            {
                for (int i = 0; i < dependencies.Length; i++)
                {
                    if (dependencies[i] == dependency) return true;
                }
            }
            return false;
        }

        /// <summary>Checks if 'dependant' is dependant on 'dependency'.</summary>
        public static bool HasDependency(object dependant, Type dependency)
        {
            if (dependant != null)
                return HasDependency(dependant.GetType(), dependency);
            else
                return false;
        }

        /************************************************************************************************************************/
    }

    /************************************************************************************************************************/

    public static partial class Utils
    {
        /************************************************************************************************************************/

        /// <summary>
        /// Returns true if [on] is a dependency of [dependant].
        /// </summary>
        public static bool IsDependantOn<T>(this IDependant<T> dependant, T on)
        {
            IEnumerable<T> dependencies = dependant.Dependencies;
            if (dependencies == null) return false;

            foreach (var dependency in dependencies)
            {
                if (EqualityComparer<T>.Default.Equals(dependency, on))
                    return true;
            }

            return false;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Sorts a collection of types according to their <see cref="TypeDependencyAttribute"/>s.
        /// If TypeA depends on TypeB, TypeA will be put later in the output list.
        /// </summary>
        /// <param name="types">The collection of types to sort. If any item depends on a type that isn't present, it will be added automatically.</param>
        /// <param name="ignoreCycles">If false, an <see cref="ArgumentException"/> will be thrown when a cyclic dependency is encountered</param>
        public static List<Type> TopologicalSort(IEnumerable<Type> types, bool ignoreCycles = false)
        {
            var dependencies = new Dictionary<Type, Type[]>();
            foreach (Type type in types)
            {
                Type[] typeDependencies = TypeDependencyAttribute.GetDependencies(type);
                if (typeDependencies != null)
                    dependencies.Add(type, typeDependencies);
            }

            return TopologicalSort(types, delegate (Type key)
            {
                Type[] value;
                dependencies.TryGetValue(key, out value);
                return value;
            }, null, ignoreCycles);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Sorts a collection of <see cref="IDependant{T}"/>.
        /// If ItemA depends on ItemB, ItemA will be put later in the returned list.
        /// </summary>
        /// <param name="collection">The collection to sort. If any item depends on a type that isn't present, it will be added automatically.</param>
        /// <param name="ignoreCycles">If false, an <see cref="ArgumentException"/> will be thrown when a cyclic dependency is encountered.</param>
        public static List<T> TopologicalSort<T>(IEnumerable<T> collection, bool ignoreCycles = false) where T : IDependant<T>
        {
            return TopologicalSort(collection, item => item.Dependencies, null, ignoreCycles);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Sorts a collection according to a collection of dependants.
        /// If ItemA depends on ItemB, ItemA will be put later in the returned list.
        /// </summary>
        /// <param name="collection">The collection to sort. If any element depends on something that isn't present, it will be added automatically.</param>
        /// <param name="dependants">An array which specifies what each element is dependant on.</param>
        /// <param name="comparer">The equality comparer to use. Null will use the default comparer.</param>
        /// <param name="ignoreCycles">If false, an <see cref="ArgumentException"/> will be thrown when a cyclic dependency is encountered</param>
        public static List<T> TopologicalSort<T>(IEnumerable<T> collection, IEnumerable<IDependant<T>> dependants, IEqualityComparer<T> comparer = null, bool ignoreCycles = false)
        {
            var dependencies = new Dictionary<T, IEnumerable<T>>();
            IEnumerator<T> collectionEnumerator = collection.GetEnumerator();
            IEnumerator<IDependant<T>> dependencyEnumerator = dependants.GetEnumerator();
            while (collectionEnumerator.MoveNext())
            {
                dependencyEnumerator.MoveNext();
                if (dependencyEnumerator.Current != null && dependencyEnumerator.Current.Dependencies != null)
                {
                    dependencies.Add(collectionEnumerator.Current, dependencyEnumerator.Current.Dependencies);
                }
            }

            return TopologicalSort(collection, delegate (T key)
            {
                IEnumerable<T> value;
                dependencies.TryGetValue(key, out value);
                return value;
            }, comparer, ignoreCycles);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Sorts an array according to an array of dependants.
        /// If ItemA depends on ItemB, ItemA will be put later in the returned list.
        /// </summary>
        /// <param name="collection">The collection to sort. If any element depends on something that isn't present, it will be added automatically.</param>
        /// <param name="getDependencies">A delegate that can return the dependencies of any given element.</param>
        /// <param name="comparer">The equality comparer to use. Null will use the default comparer.</param>
        /// <param name="ignoreCycles">If false, an <see cref="ArgumentException"/> will be thrown when a cyclic dependency is encountered</param>
        public static List<T> TopologicalSort<T>(IEnumerable<T> collection, Func<T, IEnumerable<T>> getDependencies, IEqualityComparer<T> comparer = null, bool ignoreCycles = false)
        {
            List<T> sorted = Utils.GetList<T>();
            var visiting = new Dictionary<T, bool>(comparer);

            foreach (T item in collection)
            {
                Visit(item, getDependencies, sorted, visiting, ignoreCycles);
            }

            return sorted;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Sorts an array according to an array of dependants.
        /// If ItemA depends on ItemB, ItemA will be put later in the returned list.
        /// </summary>
        /// <param name="list">The list to sort. If any element depends on something that isn't present, it will be added automatically.</param>
        /// <param name="skip">The index at which to start sorting. Everything before this index is kept in the same order as the input list.</param>
        /// <param name="getDependencies">A delegate that can return the dependencies of any given element.</param>
        /// <param name="comparer">The equality comparer to use. Null will use the default comparer.</param>
        /// <param name="ignoreCycles">If false, an <see cref="ArgumentException"/> will be thrown when a cyclic dependency is encountered</param>
        public static List<T> TopologicalSort<T>(List<T> list, int skip, Func<T, IEnumerable<T>> getDependencies, IEqualityComparer<T> comparer = null, bool ignoreCycles = false)
        {
            List<T> sorted = Utils.GetList<T>();
            var visiting = new Dictionary<T, bool>(comparer);

            for (int i = 0; i < skip; i++)
            {
                T item = list[i];
                sorted.Add(item);
                visiting.Add(item, false);
            }

            for (; skip < list.Count; skip++)
                Visit(list[skip], getDependencies, sorted, visiting, ignoreCycles);

            return sorted;
        }

        /// <summary>
        /// Sorts an array according to an array of dependants.
        /// If ItemA depends on ItemB, ItemA will be put later in the returned list.
        /// This method assigns a new list and releases the old one to the CollectionPool.
        /// </summary>
        /// <param name="list">The list to sort. If any element depends on something that isn't present, it will be added automatically.</param>
        /// <param name="skip">The index at which to start sorting. Everything before this index is kept in the same order as the input list.</param>
        /// <param name="getDependencies">A delegate that can return the dependencies of any given element.</param>
        /// <param name="comparer">The equality comparer to use. Null will use the default comparer.</param>
        /// <param name="ignoreCycles">If false, an <see cref="ArgumentException"/> will be thrown when a cyclic dependency is encountered</param>
        public static void TopologicalSort<T>(ref List<T> list, int skip, Func<T, IEnumerable<T>> getDependencies, IEqualityComparer<T> comparer = null, bool ignoreCycles = false)
        {
            List<T> sortedList = TopologicalSort(list, skip, getDependencies, comparer, ignoreCycles);
            list.Release();
            list = sortedList;
        }

        /************************************************************************************************************************/

        private static void Visit<T>(T item, Func<T, IEnumerable<T>> getDependencies, List<T> sorted, Dictionary<T, bool> visiting, bool ignoreCycles)
        {
            if (item == null) return;

            bool isVisiting;
            if (visiting.TryGetValue(item, out isVisiting))
            {
                if (isVisiting && !ignoreCycles)
                {
                    // If you found a cyclic dependency, build it into a string and throw an exception.
                    StringBuilder text = Utils.GetStringBuilder();
                    text.Append("Cyclic dependency found: ");
                    text.Append(item.ToString());

                    T dependency = item;
                    do
                    {
                        IEnumerable<T> dependencies = getDependencies(dependency);
                        foreach (var otherDependency in dependencies)
                        {
                            visiting.TryGetValue(otherDependency, out isVisiting);
                            if (isVisiting) break;
                        }

                        text.Append(" -> ");
                        text.Append(dependency.ToString());
                    }
                    while (!visiting.Comparer.Equals(dependency, item));

                    throw new ArgumentException(text.ReleaseToString());
                }
            }
            else
            {
                visiting[item] = true;

                IEnumerable<T> dependencies = getDependencies(item);
                if (dependencies != null)
                {
                    foreach (var dependency in dependencies)
                    {
                        Visit(dependency, getDependencies, sorted, visiting, ignoreCycles);
                    }
                }

                visiting[item] = false;
                sorted.Add(item);
            }
        }

        /************************************************************************************************************************/
    }
}