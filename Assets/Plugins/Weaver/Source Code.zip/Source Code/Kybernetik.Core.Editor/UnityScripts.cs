﻿// Kybernetik // Copyright 2017 Kybernetik //

#if UNITY_EDITOR

using System;
using System.Collections.Generic;
using UnityEditor;

namespace Kybernetik
{
    /// <summary>A variety of utility methods relating to script assets in Unity.</summary>
    public static class UnityScripts
    {
        /************************************************************************************************************************/
        #region Script Details (Path and Execution Time)
        /************************************************************************************************************************/

        private static readonly Dictionary<Type, MonoScript>
            Scripts = new Dictionary<Type, MonoScript>();
        private static readonly Dictionary<Type, string>
            Paths = new Dictionary<Type, string>();
        private static readonly Dictionary<Type, int>
            ExecutionTimes = new Dictionary<Type, int>();

        /************************************************************************************************************************/

        static UnityScripts()
        {
            MonoScript[] scripts = MonoImporter.GetAllRuntimeMonoScripts();
            for (int i = 0; i < scripts.Length; i++)
            {
                MonoScript script = scripts[i];
                Type type = script.GetClass();
                if (type != null && !Scripts.ContainsKey(type))
                    Scripts.Add(type, script);
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Tries to get the script asset containing 'type'.
        /// </summary>
        public static MonoScript GetScript(Type type)
        {
            Type rootType = type;
            while (rootType.DeclaringType != null)
                rootType = rootType.DeclaringType;

            MonoScript script;
            Scripts.TryGetValue(rootType, out script);
            return script;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Tries to get the path of the script asset containing 'type'.
        /// </summary>
        public static string GetPath(Type type)
        {
            string path;
            if (!Paths.TryGetValue(type, out path))
            {
                MonoScript script = GetScript(type);

                if (script != null)
                    path = AssetDatabase.GetAssetPath(script);
                else
                    path = null;

                Paths.Add(type, path);
            }

            return path;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Tries to get the execution time of the script asset containing 'type'.
        /// </summary>
        public static int GetExecutionTime(Type type)
        {
            int executionTime;
            if (!ExecutionTimes.TryGetValue(type, out executionTime))
            {
                MonoScript script = GetScript(type);
                if (script != null)
                    executionTime = MonoImporter.GetExecutionOrder(script);

                ExecutionTimes.Add(type, executionTime);
            }

            return executionTime;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Custom Defines
        /************************************************************************************************************************/

        /// <summary>
        /// Defines the specified symbol for the current build platform in the Unity Project Settings.
        /// </summary>
        public static void Define(string symbol)
        {
            Define(symbol, EditorUserBuildSettings.selectedBuildTargetGroup);
        }

        /// <summary>
        /// Defines the specified symbol for the specified platform in the Unity Project Settings.
        /// </summary>
        public static void Define(string symbol, BuildTargetGroup platform)
        {
            string defines = PlayerSettings.GetScriptingDefineSymbolsForGroup(platform);

            int index;
            if (!IsDefined(defines, symbol, out index))
            {
                if (defines.Length > 0)
                    defines += ";";

                defines += symbol;

                PlayerSettings.SetScriptingDefineSymbolsForGroup(platform, defines);
                Utils.Log("Added custom define \"" + symbol + "\" to " + platform);
            }
        }

        /************************************************************************************************************************/

        private static readonly BuildTargetGroup[] AllPlatforms = (BuildTargetGroup[])Enum.GetValues(typeof(BuildTargetGroup));

        /// <summary>
        /// Undefines the specified symbol from all build platforms in the Unity Project Settings.
        /// </summary>
        public static void Undefine(string symbol)
        {
            for (int i = 0; i < AllPlatforms.Length; i++)
                Undefine(symbol, AllPlatforms[i]);
        }

        /// <summary>
        /// Undefines the specified symbol from the specified platform in the Unity Project Settings.
        /// </summary>
        public static void Undefine(string symbol, BuildTargetGroup platform)
        {
            string defines = PlayerSettings.GetScriptingDefineSymbolsForGroup(platform);

            int index;
            if (IsDefined(defines, symbol, out index))
            {
                // Remove the custom define and its semicolon.
                int count = symbol.Length;

                if (index > 0)
                {
                    index--;// Left semicolon.
                    count++;
                }
                else if (index + count < defines.Length)
                {
                    count++;// Right semicolon.
                }

                defines = defines.Remove(index, count);

                PlayerSettings.SetScriptingDefineSymbolsForGroup(platform, defines);

                Utils.Log("Removed custom define \"" + symbol + "\" from " + platform);
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Checks if the specified symbol is defined for the current build platform in the Unity Project Settings.
        /// </summary>
        public static bool IsDefined(string symbol)
        {
            return IsDefined(symbol, EditorUserBuildSettings.selectedBuildTargetGroup);
        }

        /// <summary>
        /// Checks if the specified symbol is defined for the specified platform in the Unity Project Settings.
        /// </summary>
        public static bool IsDefined(string symbol, BuildTargetGroup platform)
        {
            string defines = PlayerSettings.GetScriptingDefineSymbolsForGroup(platform);

            int index;
            return IsDefined(defines, symbol, out index);
        }

        /// <summary>
        /// Checks if 'defines' contains 'symbol', separated from other symbols by a semicolon.
        /// </summary>
        public static bool IsDefined(string defines, string symbol, out int index)
        {
            index = -1;
            while (true)
            {
                index = defines.IndexOf(symbol, index + 1);
                if (index < 0)
                    return false;

                if (index > 0 && defines[index - 1] != ';')
                    continue;

                int end = index + symbol.Length;
                if (end < defines.Length && defines[end] != ';')
                {
                    index = end;
                    continue;
                }

                return true;
            }
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
    }
}

#endif