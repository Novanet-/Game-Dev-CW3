﻿// Kybernetik // Copyright 2017 Kybernetik //

//#define LOG

#if UNITY_EDITOR
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEditor.Callbacks;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
#endif

using System;

namespace Kybernetik
{
    /// <summary>
    /// This attribute automatically registers a method to execute when Unity builds your project.
    /// <para></para>Static methods are run once at the start of a build.
    /// <para></para>Instance methods are run once for each instance of the declaring <see cref="Component"/> attached to a
    /// <see cref="GameObject"/> in each scene being built.
    /// </summary>
    [AttributeUsage(AttributeTargets.Method)]
    public sealed class PreBuildAttribute : Attribute, IComparable<PreBuildAttribute>
    {
        /************************************************************************************************************************/

        private readonly int ExecutionTime;

        /************************************************************************************************************************/

        /// <summary>Lowest execution time goes first. 0 is the default time.</summary>
        public PreBuildAttribute(int executionTime = 0)
        {
            ExecutionTime = executionTime;
        }

        /************************************************************************************************************************/

        /// <summary>Compares the <see cref="ExecutionTime"/> of 'this' to 'other'.</summary>
        public int CompareTo(PreBuildAttribute other)
        {
            return ExecutionTime.CompareTo(other.ExecutionTime);
        }

        /************************************************************************************************************************/
#if UNITY_EDITOR
        /************************************************************************************************************************/
        #region PreBuild Method Gathering
        /************************************************************************************************************************/

        private static readonly MethodInfo[] StaticMethods, InstanceMethods;

#if LOG
        private static System.Diagnostics.Stopwatch[]
            _Timers = new System.Diagnostics.Stopwatch[2];// { TotalTime, IndividualTime }
#endif

        /************************************************************************************************************************/

        static PreBuildAttribute()
        {
            // Find every method marked as a PreBuildMethod in every class and sort them by execution time.
            List<PreBuildAttribute> attributes = new List<PreBuildAttribute>();
            List<MethodInfo> methods = new List<MethodInfo>();

            // Static.
            Reflection.GetAttributedMethods<PreBuildAttribute>(Reflection.StaticBindings, attributes, methods);
            ValidateMethodSignatures(attributes, methods);
            StaticMethods = methods.ToArray();
            Array.Sort(attributes.ToArray(), StaticMethods);

            attributes.Clear();
            methods.Clear();

            // Instance.
            Reflection.GetAttributedMethods(Reflection.InstanceBindings, attributes, methods);
            ValidateMethodSignatures(attributes, methods);
            InstanceMethods = methods.ToArray();
            Array.Sort(attributes.ToArray(), InstanceMethods);

#if LOG
            if (StaticMethods.Length == 0 && InstanceMethods.Length == 0) return;

            DebugLog("<B><< Initialised Pre-Build >></B>");

            var text = Utils.GetStringBuilder();
            text.Append("<< Static Methods: ");
            text.Append(StaticMethods.Length);
            text.Append(" >>");
            for (int i = 0; i < StaticMethods.Length; i++)
            {
                text.Append("\n      [");
                text.Append(i);
                text.Append("] ");
                text.Append(StaticMethods[i].GetSignature(false, true));
            }
            DebugLog(text);

            text.Length = 0;
            text.Append("<< Instance Methods: ");
            text.Append(StaticMethods.Length);
            text.Append(" >>");
            for (int i = 0; i < InstanceMethods.Length; i++)
            {
                text.Append("\n      [");
                text.Append(i);
                text.Append("] ");
                text.Append(InstanceMethods[i].GetSignature(false, true));
            }
            DebugLog(text.ReleaseToString());

            StaticMethods.LogErrorIfModified();
            InstanceMethods.LogErrorIfModified();
#endif
        }

        /************************************************************************************************************************/

        private static void ValidateMethodSignatures(List<PreBuildAttribute> attributes, List<MethodInfo> methods)
        {
            for (int i = 0; i < methods.Count; i++)
            {
                MethodInfo method = methods[i];

                if (method.GetParameters().Length != 0 ||
                    method.IsGenericMethod)
                {
                    attributes.RemoveAt(i);
                    methods.RemoveAt(i);
                    i--;

                    Utils.LogWarning(
                        "<B>Invalid [PreBuild] method signature</B>: " + method.GetSignature() +
                        "\nThe method <B>must have no parameters and not be generic</B>. Otherwise it will be ignored." +
                        "\nMethods with a return value will be called, but the value will be ignored.");
                }
            }
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Execution
        /************************************************************************************************************************/

        private static EditorBuildSettingsScene[] _Scenes;
        private static int _CurrentSceneIndex;

        /************************************************************************************************************************/

        [PostProcessScene]
        private static void OnPostProcessScene()
        {
            if (!BuildPipeline.isBuildingPlayer)
                return;

            try
            {
                if (StaticMethods.Length == 0 && InstanceMethods.Length == 0)
                {
                    if (_CurrentSceneIndex++ == 0)
                        DebugLog("No [PreBuild] methods were found in the project.");

                    return;
                }

                if (_CurrentSceneIndex == 0)
                {
                    _Scenes = EditorBuildSettings.scenes;

                    StartDebugTimer(0);

                    InvokeStaticMethods();
                }

                if (_Scenes.Length == 0 || _CurrentSceneIndex >= _Scenes.Length) return;

                InvokeInstanceMethods();

                _CurrentSceneIndex++;
            }
            catch
            {
                _CurrentSceneIndex = 0;
                throw;
            }
        }

        /************************************************************************************************************************/

        private static void InvokeStaticMethods()
        {
            DebugLog("<< Invoking <B>Static</B> Methods >>");

            for (int i = 0; i < StaticMethods.Length; i++)
            {
                StartDebugTimer(1);

                DebugLog(StaticMethods[i].GetSignature() + "();");
                StaticMethods[i].Invoke(null, null);

                StopAndLogDebugTimer(1);
            }
        }

        /************************************************************************************************************************/

        private static void InvokeInstanceMethods()
        {
            DebugLog("<< Invoking <B>Instance</B> Methods in scene " + _CurrentSceneIndex + ": <B>" + _Scenes[_CurrentSceneIndex].path + "</B> >>");

            for (int i = 0; i < InstanceMethods.Length; i++)
            {
                InvokeMethodForAllInstances(InstanceMethods[i]);
            }
        }

        private static void InvokeMethodForAllInstances(MethodInfo method)
        {
            Scene scene = SceneManager.GetActiveScene();

            UnityEngine.Object[] instances = UnityEngine.Object.FindObjectsOfType(method.DeclaringType);
            int componentCount = instances.Length;// Cache the component count in case it changes during execution of the method.

            if (componentCount <= 0) return;

            // For each instance found.
            int i = 0;
            while (true)
            {
                // Time and invoke it.
                DebugLog(instances[i] + "." + method.Name + "();");
                StartDebugTimer(1);

                method.Invoke(instances[i], null);

                StopAndLogDebugTimer(1);

                // Increment to the next component and break out at the end.
                if (++i >= componentCount) break;

                // If a different scene has been loaded, save it and load the original scene again.
                if (SceneManager.GetActiveScene() != scene)
                {
                    Utils.LogWarning("A different scene was opened (" + SceneManager.GetActiveScene().path +
                        ") without returning to the calling scene (" + scene.path +
                        ").\nAny changes made to that scene have been saved so that the build can continue.");
                    EditorSceneManager.SaveOpenScenes();
                    EditorSceneManager.OpenScene(scene.path);
                }

                // If the next component is null, re-gather the components again.
                if (instances[i] == null)
                {
                    instances = GameObject.FindObjectsOfType(method.DeclaringType);

                    // If the component count has changed, log a warning and update the new length.
                    if (instances.Length != componentCount)
                    {
                        Utils.LogWarning("The number of " + method.DeclaringType.FullName + " instances in " + SceneManager.GetActiveScene().name +
                            " has changed while executing " + method.GetSignature() +
                            "();\nInstance Methods marked with [PreBuild] must not create or destroy any instances of their declaring type.");

                        componentCount = instances.Length;
                        if (i >= componentCount) break;
                    }
                }
            }
        }

        /************************************************************************************************************************/

        private static void OnBuildComplete()
        {
            _CurrentSceneIndex = 0;
            StopAndLogDebugTimer(0, "<B><< Pre-Build Complete: ", " >></B>");
        }

        /************************************************************************************************************************/

        /// <summary>Invokes all [<see cref="PreBuildAttribute"/>] methods.</summary>
        [MenuItem("File/Invoke Pre-Build")]
        public static void InvokePreBuild()
        {
            int sceneCount = SceneManager.sceneCountInBuildSettings;
            if (sceneCount == 0 ||
                !EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
                return;

            for (int i = 0; i < sceneCount; i++)
            {
                SceneManager.LoadScene(i);
                OnPostProcessScene();
                EditorSceneManager.SaveOpenScenes();
            }

            OnBuildComplete();
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Logging
        /************************************************************************************************************************/

        [System.Diagnostics.Conditional("LOG")]
        private static void DebugLog(object message)
        {
            Utils.Log(message);
        }

        /************************************************************************************************************************/

        [System.Diagnostics.Conditional("LOG")]
        private static void StartDebugTimer(int index)
        {
#if LOG
            _Timers[index] = System.Diagnostics.Stopwatch.StartNew();
#endif
        }

        /************************************************************************************************************************/

        [System.Diagnostics.Conditional("LOG")]
        private static void StopAndLogDebugTimer(int index, string prefix = "      -> ", string suffix = "s")
        {
#if LOG
            System.Diagnostics.Stopwatch timer = _Timers[index];
            timer.Stop();
            double seconds = timer.ElapsedTicks / (double)System.Diagnostics.Stopwatch.Frequency;
            Utils.Log(prefix + seconds + suffix);
#endif
        }

        /************************************************************************************************************************/

        [PostProcessBuild]
        private static void OnPostProcessBuild(BuildTarget target, string pathToBuiltProject)
        {
            OnBuildComplete();
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
#endif
        /************************************************************************************************************************/
    }
}