﻿// Kybernetik // Copyright 2017 Kybernetik //

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Kybernetik
{
    /// <summary>A variety of miscellaneous utility methods.</summary>
    public static partial class Utils
    {
        /************************************************************************************************************************/
        #region Collections
        /************************************************************************************************************************/

        /// <summary>
        /// If the dictionary contains a value for the given key, that value is returned.
        /// Otherwise the default value is returned.
        /// </summary>
        public static TValue Get<TKey, TValue>(this Dictionary<TKey, TValue> dictionary, TKey key, TValue defaultValue = default(TValue))
        {
            TValue value;
            if (dictionary.TryGetValue(key, out value)) return value;
            else return defaultValue;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Removes and returns the last element in a list.
        /// </summary>
        public static T Pop<T>(this List<T> list)
        {
            T value = list[list.Count - 1];
            list.RemoveAt(list.Count - 1);
            return value;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Returns a copy of 'array' with 'element' inserted at 'index'.
        /// </summary>
        public static T[] InsertAt<T>(this T[] array, int index, T element)
        {
            if (array != null && array.Length > 0)
            {
                // Create new array.
                T[] newArray = new T[array.Length + 1];

                // Copy from the start of the old array up to the index where you are inserting the new element.
                Array.Copy(array, newArray, index);

                // Assign the new element at the desired index.
                newArray[index] = element;

                // Copy the rest of the old array after the new element.
                if (index < array.Length) Array.Copy(array, index, newArray, index + 1, array.Length - index);

                return newArray;
            }
            else
            {
                return new T[] { element };
            }
        }

        /// <summary>
        /// Returns a copy of 'array' with 'element' inserted at the end.
        /// </summary>
        public static T[] InsertAt<T>(this T[] array, T element)
        {
            if (array != null && array.Length > 0)
            {
                return array.InsertAt(array.Length, element);
            }
            else
            {
                return new T[] { element };
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Returns a copy of 'array' with the element at 'index' removed.
        /// </summary>
        public static T[] RemoveAt<T>(this T[] array, int index)
        {
            // Create new arrays.
            T[] newArray = new T[array.Length - 1];

            // Copy from the start of the old array up to the target index.
            Array.Copy(array, newArray, index);

            // Skip over that index and copy the rest after that.
            Array.Copy(array, index + 1, newArray, index, newArray.Length - index);

            return newArray;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// If 'collection' doesn't already contain 'value', this method adds it and returns true.
        /// </summary>
        public static bool AddIfNew<T>(this ICollection<T> collection, T value)
        {
            if (!collection.Contains(value))
            {
                collection.Add(value);
                return true;
            }
            else return false;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Sorts 'list', maintaining the order of any elements with an identical comparison.
        /// </summary>
        public static void StableInsertionSort<T>(IList<T> list, Comparison<T> comparison)
        {
            int count = list.Count;
            for (int j = 1; j < count; j++)
            {
                T key = list[j];

                int i = j - 1;
                for (; i >= 0 && comparison(list[i], key) > 0; i--)
                {
                    list[i + 1] = list[i];
                }
                list[i + 1] = key;
            }
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Strings
        /************************************************************************************************************************/

        /// <summary>Returns a string containing the value of each element in 'collection'.</summary>
        public static string DeepToString(this IEnumerable collection, string separator)
        {
            if (collection == null)
                return "null";
            else
                return collection.GetEnumerator().DeepToString();
        }

        /// <summary>Returns a string containing the value of each element in 'collection' (each on a new line).</summary>
        public static string DeepToString(this IEnumerable collection)
        {
            return collection.DeepToString(Utils.NewLine);
        }

        /************************************************************************************************************************/

        /// <summary>Each element returned by 'enumerator' is appended to 'text'.</summary>
        public static void AppendDeepToString(StringBuilder text, IEnumerator enumerator, string separator)
        {
            text.Append("[]");
            int countIndex = text.Length - 1;
            int count = 0;

            while (enumerator.MoveNext())
            {
                text.Append(separator);
                text.Append('[');
                text.Append(count);
                text.Append("] = ");
                text.Append(enumerator.Current);

                count++;
            }

            text.Insert(countIndex, count);
        }

        /// <summary>Returns a string containing the value of each element in 'enumerator'.</summary>
        public static string DeepToString(this IEnumerator enumerator, string separator)
        {
            StringBuilder text = GetStringBuilder();
            AppendDeepToString(text, enumerator, separator);
            return text.ReleaseToString();
        }

        /// <summary>Returns a string containing the value of each element in 'enumerator' (each on a new line).</summary>
        public static string DeepToString(this IEnumerator enumerator)
        {
            return enumerator.DeepToString(Utils.NewLine);
        }

        /************************************************************************************************************************/

        /// <summary>Returns a string containing the full type name of 'collection' followed by the value of each element.</summary>
        public static string DeepToStringTyped(this IEnumerable collection)
        {
            StringBuilder text = GetStringBuilder();

            Type type = collection.GetType();
            text.Append(type.GetReference());
            if (type.IsArray)
                text.Length -= 1 + type.GetArrayRank();

            text.Append(collection.DeepToString());

            return text.ReleaseToString();
        }

        /************************************************************************************************************************/

        /// <summary>Replaces back slashes with forward slashes.</summary>
        public static string ReplaceSlashesForward(this string str)
        {
            return str.Replace('\\', '/');
        }

        /// <summary>Replaces forward slashes with back slashes.</summary>
        public static string ReplaceSlashesBack(this string str)
        {
            return str.Replace('/', '\\');
        }

        /************************************************************************************************************************/

        /// <summary>Returns 'str' with any forward slashes removed from the end.</summary>
        public static string RemoveTrailingSlashes(this string str)
        {
            int end = str.Length - 1;
            while (str[end] == '/')
            {
                end--;
            }

            return str.Substring(0, end + 1);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Increments 'index' until 'str[index]' is no longer a whitespace character.
        /// </summary>
        public static void SkipWhiteSpace(string str, ref int index)
        {
            for (; index < str.Length; index++)
            {
                if (!char.IsWhiteSpace(str[index]))
                    break;
            }
        }

        /// <summary>
        /// Decrements 'index' until 'str[index]' is no longer a whitespace character.
        /// </summary>
        public static void SkipWhiteSpaceBackwards(string str, ref int index)
        {
            for (; index >= 0; index--)
            {
                if (!char.IsWhiteSpace(str[index]))
                    break;
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Gets the index of the '.' at the start of the file extension of 'path' (or -1 if it has no file extension).
        /// </summary>
        public static int GetFileExtensionIndex(string path)
        {
            int lastSlash = path.LastIndexOf('/') + 1;

            return path.LastIndexOf('.', path.Length - 1, path.Length - lastSlash);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Compares two strings to sort files before sub folders.
        /// <para></para>Note: this method only interprets forward slashes.
        /// </summary>
        public static int CompareWithFilesBeforeFolders(string x, string y)
        {
            if (x == null)
                return y == null ? 0 : -1;
            else if (y == null) return 1;

            int lastSlashx = x.LastIndexOf('/') - 1;
            int lastSlashy = y.LastIndexOf('/') - 1;

            if (lastSlashx == lastSlashy)
                return x.CompareTo(y);

            int end = lastSlashx;
            if (end > lastSlashy) end = lastSlashy;
            if (end > x.Length) end = x.Length;
            if (end > y.Length) end = y.Length;

            for (int i = 0; i < end; i++)
            {
                char a = x[i];
                char b = y[i];
                int comparison = a.CompareTo(b);
                if (comparison != 0) return comparison;
            }

            return lastSlashx.CompareTo(lastSlashy);
        }

        // Windows file sorting function.
        //public static int StrCmpLogicalW(string x, string y)
        //{
        //    if (x != null && y != null)
        //    {
        //        int xIndex = 0;
        //        int yIndex = 0;

        //        while (xIndex < x.Length)
        //        {
        //            if (yIndex >= y.Length)
        //                return 1;

        //            if (char.IsDigit(x[xIndex]))
        //            {
        //                if (!char.IsDigit(y[yIndex]))
        //                    return -1;

        //                // Compare the numbers.
        //                List<char> xText = new List<char>();
        //                List<char> yText = new List<char>();

        //                for (int i = xIndex; i < x.Length; i++)
        //                {
        //                    var xChar = x[i];

        //                    if (char.IsDigit(xChar))
        //                        xText.Add(xChar);
        //                    else
        //                        break;
        //                }

        //                for (int j = yIndex; j < y.Length; j++)
        //                {
        //                    var yChar = y[j];

        //                    if (char.IsDigit(yChar))
        //                        yText.Add(yChar);
        //                    else
        //                        break;
        //                }

        //                int xValue = Convert.ToInt32(new string(xText.ToArray()));
        //                int yValue = Convert.ToInt32(new string(yText.ToArray()));

        //                if (xValue < yValue)
        //                    return -1;
        //                else if (xValue > yValue)
        //                    return 1;

        //                // Skip.
        //                xIndex += xText.Count;
        //                yIndex += yText.Count;
        //            }
        //            else if (char.IsDigit(y[yIndex]))
        //                return 1;
        //            else
        //            {
        //                int difference = char.ToUpperInvariant(x[xIndex]).CompareTo(char.ToUpperInvariant(y[yIndex]));
        //                if (difference > 0)
        //                    return 1;
        //                else if (difference < 0)
        //                    return -1;

        //                xIndex++;
        //                yIndex++;
        //            }
        //        }

        //        if (yIndex < y.Length)
        //            return -1;
        //    }

        //    return 0;
        //}

        /************************************************************************************************************************/

        /// <summary>
        /// Adds spaces to 'camelCase' before each uppercase letter.
        /// </summary>
        public static string ConvertCamelCaseToFriendly(string camelCase, bool uppercaseFirst = false)
        {
            StringBuilder friendly = Utils.GetStringBuilder();
            ConvertCamelCaseToFriendly(friendly, camelCase, 0, camelCase.Length, uppercaseFirst);
            return friendly.ReleaseToString();
        }

        /// <summary>
        /// Adds spaces to 'camelCase' before each uppercase letter.
        /// </summary>
        public static void ConvertCamelCaseToFriendly(StringBuilder friendly, string camelCase, int start, int end, bool uppercaseFirst = false)
        {
            friendly.Append(uppercaseFirst ?
                char.ToUpper(camelCase[start]) :
                camelCase[start]);

            start++;

            for (; start < end; start++)
            {
                char character = camelCase[start];
                if (char.IsUpper(character))// Space before upper case.
                {
                    friendly.Append(' ');
                    friendly.Append(character);

                    // No spaces between consecutive upper case, unless followed by a non-upper case.
                    start++;
                    if (start >= camelCase.Length) return;
                    else
                    {
                        character = camelCase[start];
                        if (!char.IsUpper(character))
                        {
                            start--;
                        }
                        else
                        {
                            char nextCharacter;
                            while (true)
                            {
                                start++;
                                if (start >= camelCase.Length)
                                {
                                    friendly.Append(character);
                                    return;
                                }
                                else
                                {
                                    nextCharacter = camelCase[start];

                                    if (char.IsUpper(nextCharacter))
                                    {
                                        friendly.Append(character);
                                    }
                                    else
                                    {
                                        friendly.Append(' ');
                                        friendly.Append(character);
                                        friendly.Append(nextCharacter);
                                        break;
                                    }

                                    character = nextCharacter;
                                }
                            }
                        }
                    }
                }
                else if (char.IsNumber(character))// Space before number.
                {
                    friendly.Append(' ');
                    friendly.Append(character);
                    while (true)
                    {
                        start++;
                        if (start >= camelCase.Length) return;
                        else
                        {
                            character = camelCase[start];

                            if (char.IsNumber(character))
                                friendly.Append(character);
                            else
                            {
                                start--;
                                break;
                            }
                        }
                    }
                }
                else friendly.Append(character);// Otherwise just append the character.
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Adds spaces to 'camelCase' before each uppercase letter and removes any underscores from the start.
        /// </summary>
        public static string ConvertFieldNameToFriendly(string fieldName, bool uppercaseFirst = false)
        {
            if (string.IsNullOrEmpty(fieldName))
                return "";

            StringBuilder friendly = Utils.GetStringBuilder();

            int start = 0;
            while (fieldName[start] == '_')
            {
                start++;
                if (start >= fieldName.Length)
                    return fieldName;
            }

            ConvertCamelCaseToFriendly(friendly, fieldName, start, fieldName.Length, uppercaseFirst);
            return friendly.ReleaseToString();
        }

        /************************************************************************************************************************/

        /// <summary>Appends the specified string sanitized for XML.</summary>
        public static void AppendXmlString(StringBuilder text, string str)
        {
            if (str == null)
                return;

            for (int i = 0; i < str.Length; i++)
            {
                char c = str[i];
                switch (c)
                {
                    case '<':
                        text.Append("&lt;");
                        break;
                    case '>':
                        text.Append("&gt;");
                        break;
                    default:
                        text.Append(c);
                        break;
                }
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Inserts rich text bold tags around the last word in 'text'.
        /// The following characters denote the start of a section: dot, slash, tab, new line.
        /// </summary>
        public static void ApplyBoldTagsToLastSection(this StringBuilder text, int skipSections = 0, int sectionCount = 1)
        {
            int sectionEnd = text.Length;
            int i;
            for (i = sectionEnd - 2; i >= 0; i--)
            {
                switch (text[i])
                {
                    case '.':
                    case '/':
                    case '\\':
                    case '\t':
                    case '\r':
                    case '\n':
                        if (skipSections == sectionCount)
                            sectionEnd = i;

                        if (--skipSections < 0)
                            goto FoundSectionStart;
                        else
                            break;
                }
            }

            FoundSectionStart:
            text.Insert(i + 1, "<B>");
            text.Insert(sectionEnd + 3, "</B>");
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region String Building
        /************************************************************************************************************************/

        /// <summary>
        /// 4 spaces.
        /// <para></para>
        /// Could be '\t', but this makes it easier to copy code into websites like Stack Overflow which use 4 spaces for tabs.
        /// </summary>
        public const string Tab = "    ";

        /// <summary>Appends <see cref="Tab"/> the specified number of times.</summary>
        public static StringBuilder Indent(this StringBuilder text, int indent)
        {
            if (indent > 0)
            {
                Start:

                switch (indent)
                {
                    case 1: text.Append(Tab); break;
                    case 2: text.Append(Tab + Tab); break;
                    case 3: text.Append(Tab + Tab + Tab); break;
                    default:
                        text.Append(Tab + Tab + Tab + Tab);
                        if (indent > 4)
                        {
                            indent -= 4;
                            goto Start;
                        }
                        else break;
                }
            }

            // The above code is a bit more efficient.
            //while (indent-- > 0)
            //    text.Append(Tab);

            return text;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Unity's profiler claims that each call to <see cref="Environment.NewLine"/> allocates 30 bytes of garbage
        /// so we cache the value here for AppendLineConst to use.
        /// </summary>
        public static readonly string NewLine = Environment.NewLine;

        /// <summary>
        /// This method allocates no garbage unlike <see cref="StringBuilder.AppendLine()"/> which allocates 30 bytes
        /// of garbage per call for accessing <see cref="Environment.NewLine"/> (according to Unity's profiler).
        /// </summary>
        public static StringBuilder AppendLineConst(this StringBuilder text)
        {
            return text.Append(NewLine);
        }

        /// <summary>
        /// This method allocates no garbage unlike <see cref="StringBuilder.AppendLine()"/> which allocates 30 bytes
        /// of garbage per call for accessing <see cref="Environment.NewLine"/> (according to Unity's profiler).
        /// </summary>
        public static StringBuilder AppendLineConst(this StringBuilder text, string value)
        {
            return text.Append(value).Append(NewLine);
        }

        /// <summary>
        /// This method allocates no garbage unlike <see cref="StringBuilder.AppendLine()"/> which allocates 30 bytes
        /// of garbage per call for accessing <see cref="Environment.NewLine"/> (according to Unity's profiler).
        /// </summary>
        public static StringBuilder AppendLineConst(this StringBuilder text, object value)
        {
            return text.Append(value).Append(NewLine);
        }

        /************************************************************************************************************************/
        #region String Builder Pool
        /************************************************************************************************************************/

        private static readonly List<StringBuilder> StringBuilderPool = new List<StringBuilder>();

        /************************************************************************************************************************/

        /// <summary>
        /// Gets an available string builder from the pool.
        /// Once you are done with it, give it back with <see cref="Release"/> or <seealso cref="ReleaseToString"/>
        /// </summary>
        public static StringBuilder GetStringBuilder()
        {
            if (StringBuilderPool.Count > 0)
            {
                StringBuilder builder = StringBuilderPool.Pop();

                EditorAssert(builder.Length == 0, "Retrieved a StringBuilder from the pool with a non-zero Length. " +
                    "You must not use a StringBuilder after releasing it to the pool.\n" + builder);

                builder.Length = 0;
                return builder;
            }
            else return new StringBuilder();
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Gives a string builder back to the pool.
        /// Use <see cref="ReleaseToString"/> if you also need its string.
        /// </summary>
        public static void Release(this StringBuilder builder)
        {
            builder.Length = 0;
            StringBuilderPool.Add(builder);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Gives a string builder to the pool and returns its string.
        /// Use <see cref="Release"/> if you don't need its string.
        /// </summary>
        public static string ReleaseToString(this StringBuilder builder)
        {
            string output = builder.ToString();
            builder.Release();
            return output;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Unity
        /************************************************************************************************************************/
        #region Logging
        /************************************************************************************************************************/

        /// <summary>Debug.Log(message) without the need to include the UnityEngine namespace.</summary>
        public static void Log(object message)
        {
            Debug.Log(message);
        }

        /// <summary>Debug.LogWarning(message) without the need to include the UnityEngine namespace.</summary>
        public static void LogWarning(object message)
        {
            Debug.LogWarning(message);
        }

        /// <summary>Debug.LogError(message) without the need to include the UnityEngine namespace.</summary>
        public static void LogError(object message)
        {
            Debug.LogError(message);
        }

        /************************************************************************************************************************/

        /// <summary>Debug.Log(message) with an [Obsolete] warning so you remember to remove the call.</summary>
        [Obsolete]
        public static void LogTemp(object message)
        {
            Utils.Log(message);
        }

        /************************************************************************************************************************/

        /// <summary>Logs an error message stating that 'value' is not a valid T. Useful for enums.</summary>
        public static void LogInvalidValue<T>(T value)
        {
            Utils.LogError(value + " is not a valid " + typeof(T).GetReference());
        }

        /************************************************************************************************************************/

        /// <summary>#if UNITY_EDITOR -> if (!condition) Debug.LogWarning(message).</summary>
        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        public static void EditorAssertWarning(bool condition, object message)
        {
            if (!condition)
                Utils.LogWarning(message);
        }

        /// <summary>#if UNITY_EDITOR -> if (!condition) Debug.LogError(message).</summary>
        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        public static void EditorAssert(bool condition, object message)
        {
            if (!condition)
                Utils.LogError(message);
        }

        /************************************************************************************************************************/

        /// <summary>#if UNITY_EDITOR -> if (!condition) Debug.LogWarning(getMessage()).
        /// This allows you to avoid building the message when the assertion passes.</summary>
        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        public static void EditorAssertWarning(bool condition, Func<object> getMessage)
        {
            if (!condition)
                Utils.LogWarning(getMessage());
        }

        /// <summary>#if UNITY_EDITOR -> if (!condition) Debug.LogError(getMessage()).
        /// This allows you to avoid building the message when the assertion passes.</summary>
        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        public static void EditorAssert(bool condition, Func<object> getMessage)
        {
            if (!condition)
                Utils.LogError(getMessage());
        }

        /************************************************************************************************************************/

        /// <summary>#if DEBUG -> Debug.Log(message).</summary>
        [System.Diagnostics.Conditional("DEBUG")]
        public static void DebugLog(object message)
        {
            Utils.Log(message);
        }

        /// <summary>#if DEBUG -> Debug.LogWarning(message).</summary>
        [System.Diagnostics.Conditional("DEBUG")]
        public static void DebugLogWarning(object message)
        {
            Utils.LogWarning(message);
        }

        /// <summary>#if DEBUG -> Debug.LogError(message).</summary>
        [System.Diagnostics.Conditional("DEBUG")]
        public static void DebugLogError(object message)
        {
            Utils.LogError(message);
        }

        /// <summary>#if DEBUG -> if (!condition) Debug.LogError(message).</summary>
        [System.Diagnostics.Conditional("DEBUG")]
        public static void DebugAssert(bool condition, object message)
        {
            if (!condition)
                Utils.LogError(message);
        }

        /// <summary>#if DEBUG -> if (!condition) Debug.LogWarning(message).</summary>
        [System.Diagnostics.Conditional("DEBUG")]
        public static void DebugAssertWarning(bool condition, object message)
        {
            if (!condition)
                Utils.LogWarning(message);
        }

        /// <summary>#if DEBUG -> if (!condition) Debug.Log(message).</summary>
        [System.Diagnostics.Conditional("DEBUG")]
        public static void DebugAssertLog(bool condition, object message)
        {
            if (!condition)
                Utils.Log(message);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// If RESTRICT_USAGE is defined, this method will log the name of the calling method. This is useful for
        /// verifying that certain methods are only used in certain contexts. For example, you might want to ensure
        /// that an inefficient method or class is not used in a release build of your application.
        /// </summary>
        [System.Diagnostics.Conditional("RESTRICT_USAGE")]
        public static void LogCallerIfRestricted()
        {
            StringBuilder text = GetStringBuilder();
            text.AppendReference(new System.Diagnostics.StackFrame(1).GetMethod());
            text.Append(" was called while RESTRICT_USAGE is defined.");
            Utils.LogWarning(text.ReleaseToString());
        }

        /************************************************************************************************************************/

        /// <summary>Asserts that a pair of collections are not null and have the same count.</summary>
        [System.Diagnostics.Conditional("UNITY_EDITOR")]
        public static void EditorAssertSameSize(ICollection a, ICollection b)
        {
            EditorAssert(
                a != null && b != null && a.Count == b.Count,
                "Collections are null or have different lengths");
        }

        /************************************************************************************************************************/
        #region Log Error If Modified
        /************************************************************************************************************************/

        /// <summary>
        /// Logs an error if the 'collection' is modified after calling this method.
        /// <para></para>
        /// One collection will be checked every update (in the editor or at runtime), and all collections will be checked when this assembly
        /// is unloaded.
        /// <para></para>
        /// Can be cancelled by <see cref="CancelLogErrorIfModified"/>.
        /// </summary>
        public static void LogErrorIfModified(this IEnumerable collection, string name)
        {
            LogCallerIfRestricted();

            var enumerator = collection.GetEnumerator();
            CollectionModificationChecker.Collections.Add(collection);
            CollectionModificationChecker.Enumerators.Add(enumerator);
            CollectionModificationChecker.Names.Add(name);

            List<object> duplicateCollection = new List<object>();
            while (enumerator.MoveNext())
                duplicateCollection.Add(enumerator.Current);
            CollectionModificationChecker.DuplicateEnumerators.Add(duplicateCollection.GetEnumerator());
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Cancels a previous call to <see cref="LogErrorIfModified"/>.
        /// </summary>
        public static void CancelLogErrorIfModified(this IEnumerable collection)
        {
            int index = CollectionModificationChecker.Collections.IndexOf(collection);
            if (index >= 0)
                CollectionModificationChecker.RemoveAt(index);
        }

        /************************************************************************************************************************/

        private sealed class CollectionModificationChecker
#if !UNITY_EDITOR
            : MonoBehaviour
#endif
        {
            /************************************************************************************************************************/

            public static readonly List<IEnumerable> Collections = new List<IEnumerable>();
            public static readonly List<IEnumerator> Enumerators = new List<IEnumerator>();
            public static readonly List<IEnumerator> DuplicateEnumerators = new List<IEnumerator>();
            public static readonly List<string> Names = new List<string>();

            private static readonly CollectionModificationChecker Instance;

            private static int _CurrentIndex;

            /************************************************************************************************************************/

            static CollectionModificationChecker()
            {
#if UNITY_EDITOR

                Instance = new CollectionModificationChecker();
                UnityEditor.EditorApplication.update += CheckNext;

#else

                LogCallerIfRestricted();
                
                var go = new GameObject(nameof(CollectionModificationChecker));
                DontDestroyOnLoad(go);
                go.hideFlags = HideFlags.HideAndDontSave;
                Instance = go.AddComponent<CollectionModificationChecker>();

#endif
            }

            /************************************************************************************************************************/

            private static void CheckNext()
            {
                if (Enumerators.Count == 0)
                    return;

                if (_CurrentIndex >= Enumerators.Count)
                    _CurrentIndex = 0;

                if (!CheckIfModified(_CurrentIndex))
                    _CurrentIndex++;
            }

            /************************************************************************************************************************/

#if !UNITY_EDITOR
            private void Update()
            {
                CheckNext();
            }
#endif

            /************************************************************************************************************************/

            private static bool CheckIfModified(int index)
            {
                try
                {
                    IEnumerator enumerator = Enumerators[index];
                    IEnumerator duplicateEnumerator = DuplicateEnumerators[index];
                    enumerator.Reset();
                    duplicateEnumerator.Reset();

                    while (enumerator.MoveNext())
                    {
                        if (!duplicateEnumerator.MoveNext() ||
                            !Equals(enumerator.Current, duplicateEnumerator.Current))
                        {
                            goto HasBeenModified;
                        }
                    }

                    return false;
                }
                catch { }

                HasBeenModified:
                Utils.LogError("Collection has been modified: " + Names[index] +
                    ". Do not modify it after " + typeof(Utils).GetReference() + "." + nameof(LogErrorIfModified) + " has been called.");

                try
                {
                    DuplicateEnumerators[index].Reset();
                    Utils.LogError("Original: " + DuplicateEnumerators[index].DeepToString());
                    Utils.LogError("Current: " + Collections[index].DeepToString());
                }
                catch { }

                RemoveAt(index);
                return true;
            }

            /************************************************************************************************************************/

            internal static void RemoveAt(int index)
            {
                Collections.RemoveAt(index);
                Enumerators.RemoveAt(index);
                DuplicateEnumerators.RemoveAt(index);
                Names.RemoveAt(index);
            }

            /************************************************************************************************************************/

            private CollectionModificationChecker() { }

            ~CollectionModificationChecker()
            {
                for (int i = Enumerators.Count - 1; i >= 0; i--)
                    CheckIfModified(i);
            }

            /************************************************************************************************************************/
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Timer
        /************************************************************************************************************************/

        /// <summary>A simple timing system that works both in the editor and at runtime using unscaled time.</summary>
        public sealed class Timer : IDisposable
        {
            /************************************************************************************************************************/

            private static readonly List<Timer> SpareTimers = new List<Timer>();


#if UNITY_EDITOR
            private double _StartTime;
#else
            private float _StartTime;
#endif

            private string _Prefix, _Suffix;

            /************************************************************************************************************************/

            private Timer() { }

            /************************************************************************************************************************/

            /// <summary>Start a timer which will log the elapsed time when disposed.</summary>
            public static Timer Start(string prefix = null, string suffix = null)
            {
                Timer timer;
                if (SpareTimers.Count > 0)
                    timer = SpareTimers.Pop();
                else
                    timer = new Timer();

                timer._Prefix = prefix;
                timer._Suffix = suffix;
                timer.Restart();
                return timer;
            }

            /************************************************************************************************************************/

            /// <summary>Sets the current time as this timer's start time.</summary>
            public void Restart()
            {
#if UNITY_EDITOR
                _StartTime = UnityEditor.EditorApplication.timeSinceStartup;
#else
                _StartTime = Time.unscaledTime;
#endif
            }

            /************************************************************************************************************************/

            /// <summary>Returns the amount of time that has passed since this timer was started.</summary>
#if UNITY_EDITOR
            public double GetTime()
            {
                return UnityEditor.EditorApplication.timeSinceStartup - _StartTime;
            }
#else
            public float GetTime()
            {
                return Time.unscaledTime - _StartTime;
            }
#endif

            /************************************************************************************************************************/

            /// <summary>Logs the amount of time that has passed since this timer was started.</summary>
            public void LogTime()
            {
                var time = GetTime();
                Utils.Log(_Prefix + time + _Suffix);
            }

            /************************************************************************************************************************/

            /// <summary>Returns this timer to the pool to be reused.</summary>
            public void Release()
            {
                SpareTimers.Add(this);
            }

            /************************************************************************************************************************/

            /// <summary>Logs the elapsed time and releases this timer.</summary>
            public void Dispose()
            {
                LogTime();
                Release();
            }

            /************************************************************************************************************************/
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/

        /// <summary>
        /// Converts a set of HSB values to an RGB <see cref="Color"/>.
        /// </summary>
        public static Color HSBtoRGB(float hue, float saturation, float brightness)
        {
            hue %= 1;
            if (hue < 0) hue += 1;

            int index = (int)(hue * 6);

            float fraction = hue * 6 - index;

            float p = brightness * (1 - saturation);
            float q = brightness * (1 - fraction * saturation);
            float t = brightness * (1 - (1 - fraction) * saturation);

            switch (index)
            {
                case 0:
                    return new Color(brightness, t, p);
                case 1:
                    return new Color(q, brightness, p);
                case 2:
                    return new Color(p, brightness, t);
                case 3:
                    return new Color(p, q, brightness);
                case 4:
                    return new Color(t, p, brightness);
                case 5:
                    return new Color(brightness, p, q);
                default:
                    Utils.LogError("index " + index + " is invalid. This should never happen.");
                    return Color.white * brightness;
            }
        }

        /************************************************************************************************************************/

        /// <summary>Returns a string containing the hexadecimal representation of 'color'.</summary>
        public static string ColorToHex(Color32 color)
        {
            var hex = Utils.GetStringBuilder();
            AppendColorToHex(hex, color);
            return hex.ReleaseToString();
        }

        /// <summary>Appends the hexadecimal representation of 'color'.</summary>
        public static void AppendColorToHex(StringBuilder text, Color32 color)
        {
            text.Append(color.r.ToString("X2"));
            text.Append(color.g.ToString("X2"));
            text.Append(color.b.ToString("X2"));
            text.Append(color.a.ToString("X2"));
        }

        /************************************************************************************************************************/

        /// <summary>Appends the a rich text color tag around 'message'.</summary>
        public static void AppendColorTag(StringBuilder text, Color32 color, string message)
        {
            text.Append("<color=#");
            Utils.AppendColorToHex(text, color);
            text.Append('>');
            text.Append(message);
            text.Append("</color>");
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Sets 'transform.hideFlags' = 'flags' and does the same for all the children of 'transform'.
        /// </summary>
        public static void SetHideFlagsRecursive(Transform transform, HideFlags flags)
        {
            transform.gameObject.hideFlags = flags;

            for (int i = 0; i < transform.childCount; i++)
            {
                SetHideFlagsRecursive(transform.GetChild(i), flags);
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// In the editor, we save in the project folder (just outside Assets).
        /// Otherwise we save in the persistent data path.
        /// </summary>
        public static string GetSavePath(string fileName)
        {
#if UNITY_EDITOR
            return Application.dataPath.Substring(0, Application.dataPath.Length - 6) + fileName;
#else
            return string.Concat(Application.persistentDataPath, "/", fileName);
#endif
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Truncate the given string so it can be used in a GUI.Label.
        /// MaxLength = 16,382.
        /// </summary>
        public static string TruncateForLabel(string text)
        {
            const int MaxLength = 16382;// 16384 is a power of 2.
            if (text.Length > MaxLength)
                return text.Substring(0, MaxLength);
            else
                return text;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Combines two textures into one. The 'top' texture is alpha-blended onto the 'bottom'.
        /// </summary>
        /// <param name="bottom">The base texture to start with.</param>
        /// <param name="top">The texture to alpha-blend onto the 'bottom'</param>
        /// <param name="border">The edges of the 'top' texture are scaled down by this value.</param>
        public static RenderTexture CombineTextures(Texture bottom, Texture top, float border)
        {
            GL.PushMatrix();
            GL.LoadPixelMatrix(-border, 1 + border, 1 + border, -border);

            Rect screenRect = new Rect(0, 0, 1, 1);

            RenderTexture combined = new RenderTexture(bottom.width, bottom.height, 0);
            RenderTexture.active = combined;

            Graphics.Blit(bottom, combined);
            Graphics.DrawTexture(screenRect, top);

            RenderTexture.active = null;

            GL.PopMatrix();
            return combined;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Returns a collection of all <see cref="GameObject"/>s in the currently open scenes.
        /// </summary>
        public static T FindAllGameObjects<T>() where T : ICollection<GameObject>, new()
        {
            var objects = CollectionPool<T, GameObject>.Get();
            FindAllGameObjects(objects);
            return objects;
        }

        /// <summary>Fills an existing collection of all <see cref="GameObject"/>s in the currently open scenes.</summary>
        public static void FindAllGameObjects<T>(T collection) where T : ICollection<GameObject>
        {
            for (int i = 0; i < SceneManager.sceneCount; i++)
            {
                var roots = SceneManager.GetSceneAt(i).GetRootGameObjects();
                for (int j = 0; j < roots.Length; j++)
                {
                    GatherAllChildren(roots[j].transform, collection);
                }
            }
        }

        private static void GatherAllChildren<T>(Transform transform, T collection) where T : ICollection<GameObject>
        {
            collection.Add(transform.gameObject);

            foreach (Transform child in transform)
                GatherAllChildren(child, collection);
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Unity Editor
#if UNITY_EDITOR
        /************************************************************************************************************************/

        /// <summary>[Editor-Only]
        /// Calls <see cref="UnityEditor.EditorApplication.delayCall"/> -= then += 'method'.
        /// </summary>
        public static void EditorDelayCallOnce(UnityEditor.EditorApplication.CallbackFunction method)
        {
            UnityEditor.EditorApplication.delayCall -= method;
            UnityEditor.EditorApplication.delayCall += method;
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only]
        /// Registers the specified method to be called by the editor repeatedly at roughly the specified interval.
        /// </summary>
        public static UnityEditor.EditorApplication.CallbackFunction EditorInvokeRepeating(Action method, double interval)
        {
            double nextCallTime = UnityEditor.EditorApplication.timeSinceStartup + interval;

            UnityEditor.EditorApplication.CallbackFunction update = delegate
            {
                if (UnityEditor.EditorApplication.timeSinceStartup >= nextCallTime)
                {
                    method();
                    nextCallTime = UnityEditor.EditorApplication.timeSinceStartup + interval;
                }
            };

            UnityEditor.EditorApplication.update += update;
            return update;
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only]
        /// Moves an asset from 'oldPath' to 'newPath' and deletes any empty directories at 'oldPath'.
        /// </summary>
        public static void MoveAsset(string oldPath, string newPath, bool deleteEmptyDirectories = true)
        {
            // If the asset path changed, move the asset to maintain references.
            if (string.IsNullOrEmpty(oldPath) ||
                string.IsNullOrEmpty(newPath) ||
                oldPath == newPath)
                return;

            UnityEngine.Object asset = UnityEditor.AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(oldPath);
            if (asset == null)
                return;

            Debug.Log("Asset moved from " + oldPath + " to " + newPath, asset);

            string newDirectory = Path.GetDirectoryName(newPath);
            if (!string.IsNullOrEmpty(newDirectory))
            {
                Directory.CreateDirectory(newDirectory);
                UnityEditor.AssetDatabase.Refresh();
            }

            string error = UnityEditor.AssetDatabase.MoveAsset(oldPath, newPath);
            if (!string.IsNullOrEmpty(error))
            {
                LogError(error);
                return;
            }

            if (deleteEmptyDirectories)
                DeleteEmptyDirectories(Path.GetDirectoryName(oldPath));
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only]
        /// Deletes the specified asset. If the asset's directory is then empty, it is deleted as well (recursively).
        /// </summary>
        public static void DeleteAsset(string assetPath, bool deleteEmptyDirectories = true)
        {
            UnityEditor.AssetDatabase.DeleteAsset(assetPath);

            if (deleteEmptyDirectories)
                DeleteEmptyDirectories(Path.GetDirectoryName(assetPath));
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only]
        /// Deletes the specified directory if it is empty (ignoring metadata files), then does the same recursively
        /// for each parent directory. Refreshes the <see cref="UnityEditor.AssetDatabase"/> if anything was deleted.
        /// </summary>
        public static void DeleteEmptyDirectories(string path)
        {
            bool refresh = false;

            path = path.RemoveTrailingSlashes();

            do
            {
                if (!Directory.Exists(path))
                    break;

                string[] files;
                if (ContainsNonMetaFiles(path, out files))
                {
                    break;
                }
                else
                {
                    for (int i = 0; i < files.Length; i++)
                        File.Delete(files[i]);

                    Directory.Delete(path);
                    refresh = true;
                }

                path = Path.GetDirectoryName(path);
            }
            while (path != null);

            if (refresh)
                UnityEditor.AssetDatabase.Refresh();
        }

        /************************************************************************************************************************/

        /// <summary>
        /// [Editor-Only] Checks if the specified directory contains any files which don't end with ".meta".
        /// </summary>
        public static bool ContainsNonMetaFiles(string directory, out string[] files)
        {
            files = Directory.GetFileSystemEntries(directory);

            for (int i = 0; i < files.Length; i++)
                if (!files[i].EndsWith(".meta"))
                    return true;

            return false;
        }

        /************************************************************************************************************************/
        #region Sub Assets
        /************************************************************************************************************************/

        /// <summary>
        /// [Editor-Only] After you save the scene object 'obj' as an asset file and load it as 'asset', this method
        /// goes through all the serialized <see cref="UnityEngine.Object"/> fields which weren't saved and adds them
        /// as sub-assets. Returns true if any sub-assets were saved.
        /// <para></para>
        /// For example, creating a procedural <see cref="Mesh"/>, assigning it to a <see cref="MeshFilter"/>, and
        /// saving the object as a prefab would not save the mesh anywhere unless you call this method or
        /// <see cref="UnityEditor.AssetDatabase.AddObjectToAsset(UnityEngine.Object, UnityEngine.Object)"/>.
        /// </summary>
        public static bool SaveSubAssets(UnityEngine.Object obj, UnityEngine.Object asset)
        {
            Dictionary<UnityEngine.Object, bool> checkedObjects = Utils.GetDictionary<UnityEngine.Object, bool>();
            bool hasSubAssets = GatherSubAssets(obj, asset, checkedObjects);
            checkedObjects.Release();

            if (hasSubAssets)
            {
                UnityEditor.AssetDatabase.ImportAsset(UnityEditor.AssetDatabase.GetAssetPath(asset));
                return true;
            }
            else return false;
        }

        /************************************************************************************************************************/

        private static bool GatherSubAssets(UnityEngine.Object target, UnityEngine.Object asset, Dictionary<UnityEngine.Object, bool> checkedObjects)
        {
            // checkedObjects contains objects mapped to a value indicating if they are sub assets.

            if (checkedObjects.ContainsKey(target))
                return false;

            checkedObjects.Add(target, false);

            if (!MightHaveSubAssets(target))
                return false;

            UnityEditor.SerializedProperty targetProperty = new UnityEditor.SerializedObject(target).GetIterator();
            if (!targetProperty.Next(true))
                return false;

            UnityEditor.SerializedObject assetObject = new UnityEditor.SerializedObject(asset);
            bool modified = false;
            bool hasSubAssets = false;

            do
            {
                if (targetProperty.propertyType != UnityEditor.SerializedPropertyType.ObjectReference)
                    continue;

                UnityEngine.Object obj = targetProperty.objectReferenceValue;
                if (obj == null)
                    continue;

                UnityEditor.SerializedProperty assetProperty = assetObject.FindProperty(targetProperty.propertyPath);
                if (assetProperty == null)
                    continue;

                if (assetProperty.objectReferenceValue == null)
                {
                    bool isSubAsset;
                    if (checkedObjects.TryGetValue(obj, out isSubAsset))
                    {
                        if (isSubAsset)
                            goto ReAssignObject;
                        else
                            continue;
                    }

                    if (obj is GameObject ||
                        obj is Component ||
                        UnityEditor.AssetDatabase.Contains(obj))
                        continue;

                    Utils.DebugLog("Saving Sub Asset: " + obj + " in asset: " + obj);

                    checkedObjects.Add(obj, true);

                    UnityEditor.AssetDatabase.AddObjectToAsset(obj, asset);

                    ReAssignObject:
                    assetProperty.objectReferenceValue = obj;

                    modified = true;
                    hasSubAssets = true;
                }
                else
                {
                    if (GatherSubAssets(obj, assetProperty.objectReferenceValue, checkedObjects))
                        hasSubAssets = true;
                }
            }
            while (targetProperty.Next(true));

            if (modified)
                assetObject.ApplyModifiedPropertiesWithoutUndo();

            return hasSubAssets;
        }

        /************************************************************************************************************************/

        private static bool MightHaveSubAssets(UnityEngine.Object obj)
        {
            // Using a Dictionary for this increases the startup time without reducing the execution time.

            if (obj is GameObject ||
                obj is Transform ||
                obj is MonoBehaviour ||
                obj is ScriptableObject)
                return true;

            if (obj is Rigidbody ||
                obj is Rigidbody2D ||
                obj is Material ||
                obj is Texture ||
                obj is AudioClip ||
                obj is TextAsset ||
                obj is ParticleSystem ||
                obj is Mesh ||
                obj is PhysicMaterial ||
                obj is PhysicsMaterial2D ||
                obj is Sprite ||
                obj is RuntimeAnimatorController ||
                obj is Font ||
                obj is Flare ||
                obj is LightProbes ||
                obj is AssetBundle ||
                obj is AssetBundleManifest ||
                obj is RenderSettings ||
                obj is QualitySettings ||
                obj is Motion ||
                obj is BillboardAsset ||
                obj is LightmapSettings ||
                obj is AnimationClip ||
                obj is Avatar ||
                obj is TerrainData ||
                obj is Shader ||
                obj is ShaderVariantCollection ||
                obj is UnityEngine.Rendering.GraphicsSettings ||
                obj is UnityEngine.Audio.AudioMixer ||
                obj is UnityEngine.Audio.AudioMixerSnapshot ||
                obj is UnityEngine.Audio.AudioMixerGroup ||
                obj is NScreenBridge ||
                obj is UnityEditor.AssetImporter ||
                obj is UnityEditor.Animations.AnimatorTransitionBase ||
                obj is UnityEditor.Animations.AnimatorState ||
                obj is UnityEditor.Animations.AnimatorStateMachine ||
                // HACK: unity API upgrader breaks this because the assembly changed from Editor to Engine.
                //obj is UnityEditor.Animations.AvatarMask ||
                obj is UnityEditor.Animations.BlendTree ||
                obj is UnityEditor.DefaultAsset ||
                obj is UnityEditor.Editor ||
                obj is UnityEditor.EditorSettings ||
                obj is UnityEditor.EditorUserSettings ||
                obj is UnityEditor.EditorWindow ||
                obj is UnityEditor.Tools ||
                obj is UnityEditor.HumanTemplate ||
                obj is UnityEditor.PlayerSettings ||
                obj is UnityEditor.SceneAsset ||
                obj is UnityEditor.SubstanceArchive ||
                obj is UnityEditor.LightingDataAsset ||
                obj is UnityEditor.LightmapParameters)
                return false;

            return obj.GetType() != typeof(UnityEngine.Object);
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only] Destroys all sub-assets which are part of the specified asset.</summary>
        public static void DestroySubAssets(string assetPath)
        {
            var subAssets = UnityEditor.AssetDatabase.LoadAllAssetsAtPath(assetPath);
            for (int i = 0; i < subAssets.Length; i++)
            {
                var subAsset = subAssets[i];
                if (!(subAsset is Component) && !(subAsset is GameObject) && UnityEditor.AssetDatabase.IsSubAsset(subAsset))
                {
                    Utils.DebugLog("Destroying sub asset " + subAsset);
                    UnityEngine.Object.DestroyImmediate(subAsset, true);
                }
            }
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Object Selection
        /************************************************************************************************************************/

        /// <summary>
        /// Selects 'target' in the Unity Editor.
        /// </summary>
        public static void SelectObject(UnityEngine.Object target)
        {
            if (UnityEditor.Selection.activeObject != target)
                UnityEditor.Selection.activeObject = target;
            else
            {
                UnityEditor.Selection.activeObject = null;
                UnityEditor.EditorApplication.delayCall += delegate
                {
                    UnityEditor.Selection.activeObject = target;
                };
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Selects the specified asset in the Unity Editor.
        /// </summary>
        public static void SelectAsset(string assetPath)
        {
            if (assetPath == null)
                return;

            UnityEngine.Object asset = UnityEditor.AssetDatabase.LoadAssetAtPath(assetPath, typeof(UnityEngine.Object));

            if (asset == null)
            {
                assetPath = Utils.GetExistingParent(assetPath);
                asset = UnityEditor.AssetDatabase.LoadAssetAtPath(assetPath, typeof(UnityEngine.Object));
                if (asset == null)
                    return;
            }

            SelectObject(asset);

            // If the asset is a prefab, ping every instance of it in the scene.
            if (asset is GameObject)
            {
                UnityEngine.Object[] everything = UnityEngine.Object.FindObjectsOfType(typeof(GameObject));
                for (int i = 0; i < everything.Length; i++)
                {
                    UnityEngine.Object obj = everything[i];
                    if (UnityEditor.PrefabUtility.GetPrefabParent(obj) == asset)
                        UnityEditor.EditorGUIUtility.PingObject(obj);
                }
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Opens the specified path in Windows Explorer / Mac Finder / etc.
        /// </summary>
        public static void OpenFileLocation(string path)
        {
            if (path == null)
                return;

            UnityEditor.EditorUtility.RevealInFinder(path);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// If no file or directory exists at 'path', this method looks for the first parent directory which does exist.
        /// </summary>
        public static string GetExistingParent(string path)
        {
            if (!File.Exists(path) && !Directory.Exists(path))
            {
                while (true)
                {
                    path = Path.GetDirectoryName(path);
                    if (path == "")
                        return null;
                    else if (Directory.Exists(path))
                        break;
                }
            }

            return path;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
#endif
        #endregion
        /************************************************************************************************************************/
        #region Misc
        /************************************************************************************************************************/

        /// <summary>
        /// Re-scales value from the old range (oldMin to oldMax) to the new range (0 to 1).
        /// </summary>
        public static float LinearRescaleTo01(this float value, float oldMin, float oldMax)
        {
            if (oldMin != oldMax)
                return (value - oldMin) / (oldMax - oldMin);
            else
                return 0.5f;
        }

        /// <summary>
        /// Re-scales value from the old range (oldMin to oldMax) to the new range (newMin to newMax).
        /// </summary>
        public static float LinearRescale(this float value, float oldMin, float oldmax, float newMin, float newmax)
        {
            return value.LinearRescaleTo01(oldMin, oldmax) * (newmax - newMin) + newMin;
        }

        /// <summary>
        /// Re-scales value from the old range (oldMin to oldMax) to the new range (newMin to newMax) and clamps it within that range.
        /// </summary>
        public static float LinearRescaleClamped(this float value, float oldMin, float oldmax, float newMin, float newmax)
        {
            return Mathf.Clamp01(value.LinearRescaleTo01(oldMin, oldmax)) * (newmax - newMin) + newMin;
        }

        /************************************************************************************************************************/

        /// <summary>Creates a new email with the system's default email application.</summary>
        public static void CreateNewEmail(string address, string subject, string body)
        {
            subject = EscapeURL(subject);
            body = EscapeURL(body);

            Application.OpenURL("mailto:" + address + "? subject=" + subject + "&body=" + body);
        }

        private static string EscapeURL(string url)
        {
            return WWW.EscapeURL(url).Replace("+", "%20");
        }

        /************************************************************************************************************************/
        #region References
        /************************************************************************************************************************/

        /// <summary>Swaps the references 'a' and 'b'.</summary>
        public static void Swap<T>(ref T a, ref T b)
        {
            T temp = a;
            a = b;
            b = temp;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Sets the reference to its default value (null for reference types) and returns the original value.
        /// </summary>
        public static T Nullify<T>(ref T obj)
        {
            T temp = obj;
            obj = default(T);
            return temp;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Returns true and sets 'currentValue' if 'newValue' is different.
        /// </summary>
        public static bool SetValue<T>(ref T currentValue, T newValue) where T : struct
        {
            if (currentValue.Equals(newValue))
                return false;

            currentValue = newValue;
            return true;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Checks and sets 'currentValue' if 'newValue' is different.
        /// </summary>
        public static bool SetReference<T>(ref T currentValue, T newValue) where T : class
        {
            if (currentValue == null)
            {
                if (newValue == null) return false;
            }
            else
            {
                if (currentValue.Equals(newValue)) return false;
            }

            currentValue = newValue;
            return true;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Enums
        /************************************************************************************************************************/

        /// <summary>Returns 'T'.'obj.ToString()'. Useful for enums.</summary>
        public static string FriendlyFullName<T>(T obj)
        {
            StringBuilder text = GetStringBuilder();
            AppendFriendlyFullName(text, obj);
            return text.ReleaseToString();
        }

        /// <summary>Appends 'Type'.'obj.ToString()'. Useful for enums.</summary>
        public static void AppendFriendlyFullName<T>(StringBuilder text, T obj)
        {
            text.Append(typeof(T).GetReference());

            if (obj == null)
                text.Append(".null");
            else
                text.Append('.').Append(obj);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Caches and simplifies access to the internals of an enum type.
        /// Do not use on non-enum types.
        /// </summary>
        public static class Enum<T> where T : struct
        {
            /************************************************************************************************************************/

            /// <summary>An array of all the enum's values retrieved using <see cref="Enum.GetValues"/>.</summary>
            public static readonly T[] Values = (T[])Enum.GetValues(typeof(T));

            /// <summary>An array of all the enum's values converted to unsigned longs to allow bitwise operations.</summary>
            public static readonly ulong[] MaskValues;

            /************************************************************************************************************************/

            static Enum()
            {
                Utils.EditorAssert(typeof(T).IsEnum, () =>
                    typeof(T).GetReference() + "should not be used in " + typeof(Enum<T>).GetReference() + " because it is not an enum type.");

                MaskValues = new ulong[Values.Length];
                for (int i = 0; i < MaskValues.Length; i++)
                    MaskValues[i] = Convert.ToUInt64(Values[i]);
            }

            /************************************************************************************************************************/

            /// <summary>
            /// Returns an array containing the name of each value in the enum.
            /// Also includes the tooltip of any values with a <see cref="TooltipAttribute"/>.
            /// </summary>
            public static GUIContent[] GetGUIContents()
            {
                GUIContent[] contents = new GUIContent[Values.Length];
                for (int i = 0; i < contents.Length; i++)
                {
                    GUIContent content = new GUIContent(Values[i].ToString());
                    contents[i] = content;

                    var members = typeof(T).GetMember(content.text);
                    if (members.Length == 0)
                        continue;

                    var member = members[0];
                    TooltipAttribute tooltip = member.GetCustomAttribute<TooltipAttribute>();
                    if (tooltip != null)
                        content.tooltip = tooltip.tooltip;

                }
                return contents;
            }

            /************************************************************************************************************************/
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Get a list of all the individual flags in 'value'.
        /// </summary>
        public static List<T> GetFlags<T>(T value) where T : struct
        {
            ulong bits = Convert.ToUInt64(value);
            List<T> results = Utils.GetList<T>();
            for (int i = Enum<T>.Values.Length - 1; i >= 0; i--)
            {
                ulong mask = Enum<T>.MaskValues[i];

                if (i == 0 && mask == 0)
                    break;

                if ((bits & mask) == mask)
                {
                    results.Add(Enum<T>.Values[i]);
                    bits -= mask;
                }
            }

            return results;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Get a list of all the enum values contained in 'value'.
        /// </summary>
        public static List<T> GetFlagsFull<T>(T value) where T : struct
        {
            ulong bits = Convert.ToUInt64(value);
            List<T> results = Utils.GetList<T>();
            for (int i = Enum<T>.Values.Length - 1; i >= 0; i--)
            {
                ulong mask = Enum<T>.MaskValues[i];

                // Only include the zero value if there is nothing else.
                if (mask == 0 && results.Count > 0)
                    continue;

                if ((bits & mask) == mask)
                {
                    results.Add(Enum<T>.Values[i]);
                }
            }

            return results;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Appends all the enum values contained in 'value'.
        /// </summary>
        public static void AppendFlagsFull<T>(StringBuilder text, T value, bool fullTypeName) where T : struct
        {
            List<T> flags = GetFlagsFull(value);

            string typeName = fullTypeName ? typeof(T).GetReference() : typeof(T).Name;

            text.Append(typeName).Append(".").Append(flags[0]);
            for (int i = 1; i < flags.Count; i++)
                text.Append(" | ").Append(typeName).Append(".").Append(flags[i]);
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
    }
}