// Kybernetik // Copyright 2017 Kybernetik //

using System.Collections.Generic;
using System.Text;

namespace Kybernetik
{
    /// <summary>A variety of miscellaneous utility methods.</summary>
    public static partial class Utils
    {
        /************************************************************************************************************************/

        /// <summary>
        /// Maintains a pool of ICollections so they can be reused without garbage collection.
        /// </summary>
        public static class CollectionPool<TCollection, TElement> where TCollection : ICollection<TElement>, new()
        {
            /************************************************************************************************************************/

            // Not a Stack because it would create an unnecessary dependency on System.dll.
            private static readonly List<TCollection> Pool = new List<TCollection>();

            /************************************************************************************************************************/

            /// <summary>
            /// Returns an available collection from the pool or creates a new one if there are none.
            /// </summary>
            public static TCollection Get()
            {
                if (Pool.Count > 0)
                {
                    TCollection collection = Pool.Pop();

                    Utils.EditorAssert(collection.Count == 0, () => typeof(Utils).GetReference() +
                        "." + typeof(CollectionPool<TCollection, TElement>).GetReference() + "." + nameof(Get) +
                        " returned a non-empty list. You should never use a list after releasing it.");

                    return collection;
                }
                else
                {
                    return new TCollection();
                }
            }

            /************************************************************************************************************************/

            /// <summary>
            /// Clears a collection and puts it into the pool to be available for future use.
            /// </summary>
            public static void Release(TCollection collection)
            {
                collection.Clear();
                Pool.Add(collection);
            }

            /************************************************************************************************************************/
        }

        /************************************************************************************************************************/
        #region List Pool
        /************************************************************************************************************************/

        /// <summary>
        /// Returns an available <see cref="List{T}"/> from the pool or creates a new one if there are none.
        /// </summary>
        public static List<T> GetList<T>()
        {
            return CollectionPool<List<T>, T>.Get();
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Clears the 'list' and puts it into the pool to be available for reuse.
        /// </summary>
        public static void Release<T>(this List<T> list)
        {
            CollectionPool<List<T>, T>.Release(list);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Appends a call to release the specified list.
        /// </summary>
        public static void AppendReleaseList(StringBuilder text, string listName)
        {
            text.Append(typeof(Utils).GetReference());
            text.Append("." + nameof(Release) + '(');
            text.Append(listName);
            text.AppendLineConst(");");
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/

        /// <summary>
        /// Returns an available <see cref="Dictionary{TKey, TValue}"/> from the pool or creates a new one if there are none.
        /// </summary>
        public static Dictionary<TKey, TValue> GetDictionary<TKey, TValue>()
        {
            return CollectionPool<Dictionary<TKey, TValue>, KeyValuePair<TKey, TValue>>.Get();
        }

        /// <summary>
        /// Clears the 'dictionary' and puts it into the pool to be available for reuse.
        /// </summary>
        public static void Release<TKey, TValue>(this Dictionary<TKey, TValue> dictionary)
        {
            CollectionPool<Dictionary<TKey, TValue>, KeyValuePair<TKey, TValue>>.Release(dictionary);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Returns an available <see cref="HashSet{T}"/> from the pool or creates a new one if there are none.
        /// </summary>
        public static HashSet<T> GetHashSet<T>()
        {
            return CollectionPool<HashSet<T>, T>.Get();
        }

        /// <summary>
        /// Clears the 'set' and puts it into the pool to be available for reuse.
        /// </summary>
        public static void Release<T>(this HashSet<T> set)
        {
            CollectionPool<HashSet<T>, T>.Release(set);
        }

        /************************************************************************************************************************/
    }
}