﻿// Kybernetik // Copyright 2017 Kybernetik //

#if UNITY_EDITOR

using System;
using System.Reflection;
using UnityEditor;
using UnityEngine;

namespace Kybernetik
{
    /// <summary>
    /// Allows for easy access to some parts of the Unity Editor Console Window.
    /// </summary>
    public static class UnityConsole
    {
        /************************************************************************************************************************/

        [Flags]
        private enum EntryMode// Copied from UnityEditor.ConsoleWindow.
        {
            Error = 1 << 0,
            Assert = 1 << 1,
            Log = 1 << 2,
            // Why no 1 << 3 ?
            Fatal = 1 << 4,
            DontPreprocessCondition = 1 << 5,
            AssetImportError = 1 << 6,
            AssetImportWarning = 1 << 7,
            ScriptingError = 1 << 8,
            ScriptingWarning = 1 << 9,
            ScriptingLog = 1 << 10,
            ScriptCompileError = 1 << 11,
            ScriptCompileWarning = 1 << 12,
            StickyError = 1 << 13,
            MayIgnoreLineNumber = 1 << 14,
            ReportBug = 1 << 15,
            DisplayPreviousErrorInStatusBar = 1 << 16,
            ScriptingException = 1 << 17,
            DontExtractStacktrace = 1 << 18,
            ShouldClearOnPlay = 1 << 19,
            GraphCompileError = 1 << 20,
            ScriptingAssertion = 1 << 21,
        }

        /************************************************************************************************************************/

        private static readonly Action ClearConsole;
        private static readonly Func<int> StartGettingEntries;
        private static readonly Action EndGettingEntries;
        private static readonly MethodInfo GetEntry;
        private static readonly FieldInfo EntryModeField;
        private static readonly object UnityLogEntry;

        /************************************************************************************************************************/

        static UnityConsole()
        {
            Assembly assembly = Assembly.GetAssembly(typeof(EditorApplication));
            Type logEntriesType = assembly.GetType("UnityEditorInternal.LogEntries");
            if (logEntriesType == null)
            {
                InitialisationFailed("unable to find the UnityEditorInternal.LogEntries class.");
                return;
            }

            MethodInfo method = logEntriesType.GetMethod("Clear");
            Reflection.GetDelegate(method, out ClearConsole);
            if (ClearConsole == null)
            {
                InitialisationFailed("unable to find the UnityEditorInternal.LogEntries.Clear method.");
                return;
            }

            method = logEntriesType.GetMethod("StartGettingEntries");
            Reflection.GetDelegate(method, out StartGettingEntries);
            if (StartGettingEntries == null)
            {
                InitialisationFailed("unable to find the UnityEditorInternal.LogEntries.StartGettingEntries method.");
                return;
            }

            method = logEntriesType.GetMethod("EndGettingEntries");
            Reflection.GetDelegate(method, out EndGettingEntries);
            if (EndGettingEntries == null)
            {
                InitialisationFailed("unable to find the UnityEditorInternal.LogEntries.EndGettingEntries method.");
                return;
            }

            GetEntry = logEntriesType.GetMethod("GetEntryInternal");
            if (GetEntry == null)
            {
                InitialisationFailed("unable to find the UnityEditorInternal.LogEntries.GetEntry method.");
                return;
            }

            Type logEntryType = assembly.GetType("UnityEditorInternal.LogEntry");
            if (logEntryType == null)
            {
                InitialisationFailed("unable to find the UnityEditorInternal.LogEntry class.");
                return;
            }

            EntryModeField = logEntryType.GetField("mode");
            if (EndGettingEntries == null)
            {
                InitialisationFailed("unable to find the UnityEditorInternal.LogEntry.mode field.");
                return;
            }

            UnityLogEntry = Activator.CreateInstance(logEntryType);
        }

        [System.Diagnostics.Conditional("DEBUG")]
        private static void InitialisationFailed(string message)
        {
            Utils.LogWarning("Error initialising UnityConsole: " + message);
        }

        /************************************************************************************************************************/

        /// <summary>Clears all log entries from the Unity Console Window.</summary>
        public static void Clear()
        {
            ClearConsole();
        }

        /************************************************************************************************************************/

        private static bool _HasCompileError;

        /// <summary>Checks if the Unity Editor Console Window currently contains any compile errors.</summary>
        public static bool HasCompileError()
        {
            // Once an error is detected, it won't be cleared until scripts are recompiled and assemblies are reloaded.
            if (_HasCompileError)
                return true;

            // If the LogEntry object wasn't created, some of the reflection in the cctor must have failed.
            if (UnityLogEntry == null)
                return false;

            // If we don't have any compile errors, we need to keep checking all log entries every time since Unity
            // won't reload this assembly if a compile error occurs.

            int count = StartGettingEntries();
            try
            {
                while (count-- > 0)
                {
                    if (!(bool)GetEntry.Invoke(null, Reflection.TwoObjects(count, UnityLogEntry)))
                        break;

                    var mode = (EntryMode)EntryModeField.GetValue(UnityLogEntry);
                    if ((mode & EntryMode.ScriptCompileError) == EntryMode.ScriptCompileError)
                    {
                        _HasCompileError = true;
                        return true;
                    }
                }

                return false;
            }
            finally
            {
                EndGettingEntries();
            }
        }

        /************************************************************************************************************************/
    }
}

#endif