﻿// Kybernetik // Copyright 2017 Kybernetik //

//#define UNIT_TEST

using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Text;

namespace Kybernetik
{
    /// <summary>
    /// A variety of methods relating to C# code.
    /// Particularly useful for generating procedural code.
    /// </summary>
    public static class CSharp
    {
        /************************************************************************************************************************/

        static CSharp()
        {
            Utils.LogCallerIfRestricted();
        }

        /************************************************************************************************************************/
        #region Type References
        /************************************************************************************************************************/

        private static readonly Dictionary<Type, string>
            TypeReferences = new Dictionary<Type, string>
            {
                { typeof(object), "object" },
                { typeof(void), "void" },
                { typeof(bool), "bool" },
                { typeof(byte), "byte" },
                { typeof(sbyte), "sbyte" },
                { typeof(char), "char" },
                { typeof(string), "string" },
                { typeof(short), "short" },
                { typeof(int), "int" },
                { typeof(long), "long" },
                { typeof(ushort), "ushort" },
                { typeof(uint), "uint" },
                { typeof(ulong), "ulong" },
                { typeof(float), "float" },
                { typeof(double), "double" },
                { typeof(decimal), "decimal" },
            };

        /************************************************************************************************************************/

        /// <summary>
        /// Returns the full name of a 'type' as it would appear in C# code.
        /// <para></para>
        /// For example, typeof(List&lt;float&gt;).FullName would give you:
        /// System.Collections.Generic.List`1[[System.Single, mscorlib, Version=2.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089]]
        /// <para></para>
        /// This method would instead return System.Collections.Generic.List&lt;float&gt;.
        /// <para></para>
        /// Note that all returned values are stored in a dictionary to speed up repeated use.
        /// </summary>
        public static string GetReference(this Type type)
        {
            if (type == null)
                return "";

            // Check if we have already got the output for that type.
            string reference;
            if (TypeReferences.TryGetValue(type, out reference))
                return reference;

            StringBuilder text = Utils.GetStringBuilder();

            if (type.IsArray)// Array = TypeName[].
            {
                text.Append(type.GetElementType().GetReference());

                text.Append('[');
                int dimensions = type.GetArrayRank();
                while (dimensions-- > 1)
                    text.Append(",");
                text.Append(']');

                goto Return;
            }

            if (type.IsPointer)// Pointer = TypeName*.
            {
                text.Append(type.GetElementType().GetReference());
                text.Append('*');

                goto Return;
            }

            if (type.IsGenericParameter)// Generic Parameter = TypeName (for unspecified generic parameters).
            {
                text.Append(type.Name);
                goto Return;
            }

            Type underlyingType = Nullable.GetUnderlyingType(type);
            if (underlyingType != null)// Nullable = TypeName?.
            {
                text.Append(underlyingType.GetReference());
                text.Append('?');

                goto Return;
            }

            // Other Type = Namespace.NestedTypes.TypeName<GenericArguments>.

            if (type.Namespace != null)// Namespace.
            {
                text.Append(type.Namespace);
                text.Append('.');
            }

            int genericArguments = 0;

            if (type.DeclaringType != null)// Account for Nested Types.
            {
                // Count the nesting level.
                int nesting = 1;
                Type declaringType = type.DeclaringType;
                while (declaringType.DeclaringType != null)
                {
                    declaringType = declaringType.DeclaringType;
                    nesting++;
                }

                // Append the name of each outer type, starting from the outside.
                while (nesting-- > 0)
                {
                    // Walk out to the current nesting level.
                    // This avoids the need to make a list of types in the nest or to insert type names instead of appending them.
                    declaringType = type;
                    for (int i = nesting; i >= 0; i--)
                        declaringType = declaringType.DeclaringType;

                    // Nested Type Name.
                    text.Append(declaringType.Name);
                    AppendGenericArguments(text, declaringType, ref genericArguments);
                    text.Append('.');
                }
            }

            // Type Name.
            text.Append(type.Name);
            AppendGenericArguments(text, type, ref genericArguments);

            Return:// Remember and return the reference.
            reference = text.ReleaseToString();
            TypeReferences.Add(type, reference);
            return reference;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Appends the generic arguments of 'type' (after skipping the specified number).
        /// </summary>
        public static void AppendGenericArguments(StringBuilder text, Type type, ref int skipGenericArguments)
        {
            if (type.IsGenericType)
            {
                int backQuote = type.Name.IndexOf('`');
                if (backQuote >= 0)
                {
                    text.Length -= type.Name.Length - backQuote;

                    Type[] genericArguments = type.GetGenericArguments();
                    if (skipGenericArguments >= genericArguments.Length)
                        return;

                    text.Append('<');

                    Type firstArgument = genericArguments[skipGenericArguments];
                    skipGenericArguments++;

                    if (firstArgument.IsGenericParameter)
                    {
                        while (skipGenericArguments < genericArguments.Length)
                        {
                            text.Append(',');
                            skipGenericArguments++;
                        }
                    }
                    else
                    {
                        text.Append(firstArgument.GetReference());

                        while (skipGenericArguments < genericArguments.Length)
                        {
                            text.Append(", ");
                            text.Append(genericArguments[skipGenericArguments].GetReference());
                            skipGenericArguments++;
                        }
                    }

                    text.Append('>');
                }
            }
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Member References
        /************************************************************************************************************************/

        /// <summary>
        /// Returns the full name of a 'member' as it would appear in C# code.
        /// <para></para>
        /// For example, passing this method info in as its own parameter would return "<see cref="CSharp"/>.GetReference".
        /// <para></para>
        /// Note that when 'member' is a <see cref="Type"/>, this method calls <see cref="GetReference(Type)"/> instead.
        /// </summary>
        public static string GetReference(this MemberInfo member)
        {
            if (member == null)
                return "null";

            Type type = member as Type;
            if (type != null)
                return type.GetReference();

            StringBuilder text = Utils.GetStringBuilder();

            if (member.DeclaringType != null)
            {
                text.Append(member.DeclaringType.GetReference());
                text.Append('.');
            }

            text.Append(member.Name);

            return text.ReleaseToString();
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Appends the full name of a 'member' as it would appear in C# code.
        /// <para></para>
        /// For example, passing this method info in as its own parameter would append "<see cref="CSharp"/>.AppendReference".
        /// <para></para>
        /// Note that when 'member' is a <see cref="Type"/>, this method calls <see cref="GetReference(Type)"/> instead.
        /// </summary>
        public static StringBuilder AppendReference(this StringBuilder text, MemberInfo member)
        {
            if (member == null)
            {
                text.Append("null");
                return text;
            }

            Type type = member as Type;
            if (type != null)
            {
                text.Append(type.GetReference());
                return text;
            }

            if (member.DeclaringType != null)
            {
                text.Append(member.DeclaringType.GetReference());
                text.Append('.');
            }

            text.Append(member.Name);

            return text;
        }

        /************************************************************************************************************************/
        #region Friendly Method Names
        /************************************************************************************************************************/

        /// <summary>Returns the full name of a  'method' as it would appear in C# code. See: <see cref="GetReference(MemberInfo)"/>.</summary>
        public static string GetReference(Delegate method)
        {
            return GetReference(method.Method);
        }

        /// <summary>Returns the full name of a  'method' as it would appear in C# code. See: <see cref="GetReference(MemberInfo)"/>.</summary>
        public static string GetReference(Action method)
        {
            return GetReference(method.Method);
        }

        /// <summary>Returns the full name of a  'method' as it would appear in C# code. See: <see cref="GetReference(MemberInfo)"/>.</summary>
        public static string GetReference<T>(Action<T> method)
        {
            return GetReference(method.Method);
        }

        /// <summary>Returns the full name of a  'method' as it would appear in C# code. See: <see cref="GetReference(MemberInfo)"/>.</summary>
        public static string GetReference<TResult>(Func<TResult> method)
        {
            return GetReference(method.Method);
        }

        /// <summary>Returns the full name of a  'method' as it would appear in C# code. See: <see cref="GetReference(MemberInfo)"/>.</summary>
        public static string GetReference<T, TResult>(Func<T, TResult> method)
        {
            return GetReference(method.Method);
        }

        /// <summary>Returns the full name of a  'method' as it would appear in C# code. See: <see cref="GetReference(MemberInfo)"/>.</summary>
        public static string GetReference<T1, T2, TResult>(Func<T1, T2, TResult> method)
        {
            return GetReference(method.Method);
        }

        /************************************************************************************************************************/

        /// <summary>Appends the full name of a  'method' as it would appear in C# code. See: <see cref="AppendReference(StringBuilder, MemberInfo)"/>.</summary>
        public static StringBuilder AppendReference(this StringBuilder text, Delegate method)
        {
            return text.AppendReference(method.Method);
        }

        /// <summary>Appends the full name of a  'method' as it would appear in C# code. See: <see cref="AppendReference(StringBuilder, MemberInfo)"/>.</summary>
        public static StringBuilder AppendReference(this StringBuilder text, Action method)
        {
            return text.AppendReference(method.Method);
        }

        /// <summary>Appends the full name of a  'method' as it would appear in C# code. See: <see cref="AppendReference(StringBuilder, MemberInfo)"/>.</summary>
        public static StringBuilder AppendReference<T>(this StringBuilder text, Action<T> method)
        {
            return text.AppendReference(method.Method);
        }

        /// <summary>Appends the full name of a  'method' as it would appear in C# code. See: <see cref="AppendReference(StringBuilder, MemberInfo)"/>.</summary>
        public static StringBuilder AppendReference<TResult>(this StringBuilder text, Func<TResult> method)
        {
            return text.AppendReference(method.Method);
        }

        /// <summary>Appends the full name of a  'method' as it would appear in C# code. See: <see cref="AppendReference(StringBuilder, MemberInfo)"/>.</summary>
        public static StringBuilder AppendReference<T, TResult>(this StringBuilder text, Func<T, TResult> method)
        {
            return text.AppendReference(method.Method);
        }

        /// <summary>Appends the full name of a  'method' as it would appear in C# code. See: <see cref="AppendReference(StringBuilder, MemberInfo)"/>.</summary>
        public static StringBuilder AppendReference<T1, T2, TResult>(this StringBuilder text, Func<T1, T2, TResult> method)
        {
            return text.AppendReference(method.Method);
        }

        /************************************************************************************************************************/

        /// <summary>Appends the signature of 'method' as it would appear in C# code.</summary>
        public static void AppendSignature(this MethodInfo method, StringBuilder text,
            bool returnType = true, bool declaringType = true, bool parameterTypes = true, bool parameterDetails = true)
        {
            if (method == null)
            {
                text.Append("null");
                return;
            }

            if (returnType)
            {
                text.Append(method.ReturnType.Name);
                text.Append(' ');
            }

            if (declaringType)
            {
                text.Append(method.DeclaringType.GetReference());
                text.Append('.');
            }

            text.Append(method.Name);

            if (method.IsGenericMethod)
            {
                text.Append('<');

                Type[] genericArguments = method.GetGenericArguments();
                for (int i = 0; i < genericArguments.Length; i++)
                {
                    text.Append(genericArguments[i].Name);
                    text.Append(", ");
                }

                text.Length -= 2;
                text.Append('>');
            }

            text.Append('(');
            {
                if (parameterTypes)
                {
                    if (method.IsDefined(typeof(ExtensionAttribute), false))
                        text.Append("this ");

                    ParameterInfo[] parameterInfos = method.GetParameters();
                    for (int i = 0; i < parameterInfos.Length; i++)
                    {
                        ParameterInfo parameter = parameterInfos[i];

                        if (parameter.IsOut)
                            text.Append("out ");
                        else if (parameter.ParameterType.IsByRef)
                            text.Append("ref ");

                        text.Append(parameter.ParameterType.GetReference());

                        if (parameterDetails)
                        {
                            text.Append(' ');
                            text.Append(parameter.Name);

                            if (parameter.IsOptional)
                            {
                                text.Append('=');
                                text.Append(parameter.DefaultValue);
                            }
                        }

                        text.Append(", ");
                    }

                    if (parameterInfos.Length > 0)
                        text.Length -= 2;
                }
            }
            text.Append(')');
        }

        /// <summary>Returns the signature of 'method' as it would appear in C# code.</summary>
        public static string GetSignature(this MethodInfo method,
            bool returnType = true, bool declaringType = true, bool parameters = true, bool parameterDetails = true)
        {
            if (method == null) return "Null";

            StringBuilder text = Utils.GetStringBuilder();
            method.AppendSignature(text, returnType, declaringType, parameters, parameterDetails);
            return text.ReleaseToString();
        }

        /************************************************************************************************************************/

        /// <summary>Appends the signature of a method with the specified details as it would appear in C# code.</summary>
        public static void AppendMethodSignature(StringBuilder text,
            Type returnType, Type declaringType, string methodName, Type[] genericArguments, Type[] parameterTypes)
        {
            if (returnType != null)
            {
                text.Append(returnType.Name);
                text.Append(' ');
            }

            if (declaringType != null)
            {
                text.Append(declaringType.GetReference());
                text.Append('.');
            }

            text.Append(methodName);

            if (genericArguments != null)
            {
                text.Append('<');

                text.Append(genericArguments[0].Name);
                for (int i = 1; i < genericArguments.Length; i++)
                    text.Append(", ").Append(genericArguments[i].Name);

                text.Append('>');
            }

            text.Append('(');
            if (parameterTypes != null)
            {
                text.Append(parameterTypes[0].Name);
                for (int i = 1; i < parameterTypes.Length; i++)
                    text.Append(", ").Append(parameterTypes[i].Name);
            }
            text.Append(')');
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Member Naming
        /************************************************************************************************************************/

        /// <summary>
        /// Appends the full name of the given type with underscores instead of any characters that wouldn't be valid in a symbol name.
        /// </summary>
        public static void AppendUnderscoredFullName(StringBuilder text, Type type)
        {
            int i = text.Length;

            text.Append(type.GetReference());

            while (i < text.Length)
            {
                char c = text[i];

                // Replace array brackets "[]" with the word "Array".
                // If the rank is higher than 1, append it after the word.
                if (c == '[')
                {
                    int j = i;
                    int rank = 1;

                    while (true)
                    {
                        j++;
                        if (j >= text.Length)
                            goto ValidateChar;

                        c = text[j];
                        if (c == ',')
                        {
                            rank++;
                        }
                        else if (c == ']')
                        {
                            int length = text.Length;
                            text.Remove(i, j - i + 1);
                            text.Insert(i, "_Array");
                            if (rank > 1)
                                text.Insert(i + 6, rank);
                            i += text.Length - length;

                            goto NextChar;
                        }
                        else break;
                    }
                }

                ValidateChar:
                // Replace any invalid characters with underscores.
                if (!IsValidInMemberName(c))
                {
                    text[i] = '_';
                }

                NextChar:
                i++;
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Checks if the specified char can be used in a C# symbol name.
        /// </summary>
        public static bool IsValidInMemberName(char c)
        {
            switch (c)
            {
                case ' ':
                case '.':
                case '-':
                case '+':
                case '=':
                case ',':
                case '<':
                case '>':
                case '?':
                case ';':
                case ':':
                case '\'':
                case '"':
                case '[':
                case ']':
                case '{':
                case '}':
                case '!':
                case '@':
                case '#':
                case '$':
                case '%':
                case '^':
                case '&':
                case '*':
                case '(':
                case ')':
                case '`':
                case '~':
                    return false;
                default:
                    return true;
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Converts the specified string into a valid member name by inserting an underscore at the start if
        /// necessary and replacing any invalid characters with underscores.
        /// </summary>
        public static string ValidateMemberName(string name)
        {
            return ValidateMemberName(name, 0, name.Length);
        }

        /// <summary>
        /// Converts the specified substring into a valid member name by inserting an underscore at the start if
        /// necessary and replacing any invalid characters with underscores.
        /// </summary>
        public static string ValidateMemberName(string name, int startIndex, int endIndex)
        {
            StringBuilder text = Utils.GetStringBuilder();

            if (!char.IsLetter(name[startIndex]))
                text.Append('_');

            for (; startIndex < endIndex; startIndex++)
            {
                char c = name[startIndex];
                if (IsValidInMemberName(c))
                    text.Append(c);
            }

            return text.ReleaseToString();
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Checks if converting the rawName substring into a valid member name would produce memberName.
        /// </summary>
        public static bool IsMemberNameEqual(string rawName, int startIndex, int endIndex, string memberName)
        {
            int i = 0;

            if (!char.IsLetter(rawName[startIndex]))
            {
                if (rawName[i++] != '_') return false;
                startIndex++;
            }

            for (; startIndex < endIndex; startIndex++)
            {
                char c = rawName[startIndex];
                if (IsValidInMemberName(c))
                {
                    if (memberName[i++] != c) return false;
                    else if (i >= memberName.Length) break;
                }
            }

            return i == memberName.Length;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Script Building
        /************************************************************************************************************************/

        /// <summary>text.Indent(indent++).AppendLineConst("{");</summary>
        public static void OpenScope(this StringBuilder text, ref int indent)
        {
            text.Indent(indent++).AppendLineConst("{");
        }

        /// <summary>text.Indent(--indent).AppendLineConst("}");</summary>
        public static void CloseScope(this StringBuilder text, ref int indent)
        {
            text.Indent(--indent).AppendLineConst("}");
        }

        /************************************************************************************************************************/

        /// <summary>Appends closing brackets and new lines until the nestCount reaches 0.</summary>
        public static void CloseScopeFully(this StringBuilder text, int nestCount)
        {
            while (nestCount-- > 0)
                text.Indent(nestCount).AppendLineConst("}");
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Appends the opening of a for loop: for (int i = 0; i &lt; length; i++).
        /// </summary>
        public static void AppendForLoop(StringBuilder text, int indent, string length, string iterator = "i")
        {
            text.Indent(indent);
            text.Append("for (int ");
            text.Append(iterator);
            text.Append(" = 0; ");
            text.Append(iterator);
            text.Append(" < ");
            text.Append(length);
            text.Append("; ");
            text.Append(iterator);
            text.AppendLineConst("++)");
        }

        /************************************************************************************************************************/

        /// <summary>Append "null" for classes or "default(T)" for structs.</summary>
        public static void AppendDefault<T>(StringBuilder text)
        {
            AppendDefault(text, typeof(T));
        }

        /// <summary>Append "null" for classes or "default(type)" for structs.</summary>
        public static void AppendDefault(StringBuilder text, Type type)
        {
            if (!type.IsValueType)
            {
                text.Append("null");
            }
            else
            {
                text.Append("default(");
                text.Append(type.GetReference());
                text.Append(")");
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Indents the text by the specified amount and appends #region regionName. 
        /// </summary>
        public static void AppendRegion(StringBuilder text, int indent, string regionName)
        {
            text.Indent(indent).Append("#region ").AppendLineConst(regionName);
        }

        /// <summary>
        /// Indents the text by the specified amount and appends #endregion. 
        /// </summary>
        public static void AppendEndRegion(StringBuilder text, int indent)
        {
            text.Indent(indent).AppendLineConst("#endregion");
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Unit Tests
#if UNIT_TEST
        /************************************************************************************************************************/

        [UnitTest]
        private static void UnitTestGetReference()
        {
            // Primitives.
            UnitTestGetReference("bool", typeof(bool));
            UnitTestGetReference("int", typeof(int));

            // Arrays.
            UnitTestGetReference("bool[]", typeof(bool[]));
            UnitTestGetReference("bool[][]", typeof(bool[][]));
            UnitTestGetReference("bool[,,]", typeof(bool[,,]));

            // Pointers and Nullables.
            UnitTestGetReference("bool*", typeof(bool*));
            UnitTestGetReference("bool?", typeof(bool?));

            // Generics.
            UnitTestGetReference("System.Collections.Generic.List<bool>", typeof(List<bool>));
            UnitTestGetReference("System.Collections.Generic.List<System.Collections.Generic.List<bool>[]>[]", typeof(List<List<bool>[]>[]));

            // Nested Types.
            UnitTestGetReference("Kybernetik.CSharp.Nested", typeof(Nested));
            UnitTestGetReference("Kybernetik.CSharp.Nested.Generic<float>.AnotherNested.AnotherGeneric<int>",
                typeof(Nested.Generic<float>.AnotherNested.AnotherGeneric<int>));
            UnitTestGetReference("System.Collections.Generic.List<Kybernetik.CSharp.Nested.Generic<float>>",
                typeof(List<Nested.Generic<float>>));
            UnitTestGetReference("Kybernetik.CSharp.Nested.Generic<>.AnotherNested.AnotherGeneric<>",
                typeof(Nested.Generic<>.AnotherNested.AnotherGeneric<>));// Unspecified generic parameters.
        }

        public static void UnitTestGetReference(string expected, Type type)
        {
            string reference = type.GetReference();
            if (expected != reference)
                throw new UnitTest.FailureException(expected + " ->\n" + reference);
        }

        internal class Nested
        {
            internal class Generic<T>
            {
                internal class AnotherNested
                {
                    internal class AnotherGeneric<U>
                    {
                    }
                }
            }
        }

        /************************************************************************************************************************/
#endif
        #endregion
        /************************************************************************************************************************/
    }
}
