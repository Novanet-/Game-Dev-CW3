﻿// Kybernetik // Copyright 2017 Kybernetik //

using System.Collections.Generic;
using UnityEngine;

namespace Kybernetik
{
    /// <summary>
    /// Various utility methods for using the <see cref="MeshBuilder"/> class.
    /// </summary>
    public static class MeshUtils
    {
        /************************************************************************************************************************/
        #region Mass Modification
        /************************************************************************************************************************/

        /// <summary>
        /// Adds the specified translation to all vertices in the specified range.
        /// </summary>
        public static void TranslateVertices(MeshBuilder builder, Vector3 translation, int start, int end)
        {
            while (start < end)
            {
                builder.Vertices[start++] += translation;
            }
        }

        /// <summary>
        /// Adds the specified translation to all vertices from the specified start index up to the current vertex count.
        /// </summary>
        public static void TranslateVertices(MeshBuilder builder, Vector3 translation, int start)
        {
            TranslateVertices(builder, translation, start, builder.VertexCount);
        }

        /// <summary>
        /// Adds the specified translation to all vertices up to the current vertex count.
        /// </summary>
        public static void TranslateVertices(MeshBuilder builder, Vector3 translation)
        {
            TranslateVertices(builder, translation, 0, builder.VertexCount);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Multiplies all vertices and normaly by 'rotation'.
        /// </summary>
        public static void RotateVertices(MeshBuilder builder, Quaternion rotation)
        {
            for (int i = 0; i < builder.VertexCount; i++)
            {
                builder.Vertices[i] = rotation * builder.Vertices[i];
                builder.Normals[i] = rotation * builder.Normals[i];
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Multiplies all vertices by 'scale'.
        /// </summary>
        public static void ScaleVertices(MeshBuilder builder, float scale)
        {
            for (int i = 0; i < builder.VertexCount; i++)
            {
                builder.Vertices[i] *= scale;
            }
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Duplication
        /************************************************************************************************************************/

        /// <summary>
        /// Adds a new vertex with its position at 'builder.Vertices[vertex] + offset' and the specified 'normal' and 'uv' values.
        /// </summary>
        public static void DuplicateVertex(MeshBuilder builder, int vertex, Vector3 offset, Vector3 normal, Vector2 uv)
        {
            builder.Vertices.Add(builder.Vertices[vertex] + offset);
            builder.Normals.Add(normal);
            builder.UVs.Add(uv);
        }

        /// <summary>
        /// Adds a new vertex with its position at 'builder.Vertices[vertex]' and the specified 'normal' and 'uv' values.
        /// </summary>
        public static void DuplicateVertex(MeshBuilder builder, int vertex, Vector3 normal, Vector2 uv)
        {
            builder.Vertices.Add(builder.Vertices[vertex]);
            builder.Normals.Add(normal);
            builder.UVs.Add(uv);
        }

        /// <summary>
        /// Adds a new vertex with its position at 'builder.Vertices[vertex]' and the specified 'normal' value.
        /// </summary>
        public static void DuplicateVertex(MeshBuilder builder, int vertex, Vector3 normal)
        {
            builder.Vertices.Add(builder.Vertices[vertex]);
            builder.Normals.Add(normal);
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Quads
        /************************************************************************************************************************/

        /// <summary>
        /// Adds 4 vertices to form a quad.
        /// </summary>
        public static void PlaceQuadVertices(List<Vector3> vertices, Vector3 bottomLeft, Vector2 size)
        {
            vertices.Add(bottomLeft);

            bottomLeft.y += size.y;
            vertices.Add(bottomLeft);

            bottomLeft.x += size.x;
            vertices.Add(bottomLeft);

            bottomLeft.y -= size.y;
            vertices.Add(bottomLeft);
        }

        /// <summary>
        /// Adds 4 UV values to planar map a quad.
        /// </summary>
        public static void PlaceQuadUVs(List<Vector2> uvs, Vector2 bottomLeft, Vector2 size)
        {
            uvs.Add(bottomLeft);

            bottomLeft.y += size.y;
            uvs.Add(bottomLeft);

            bottomLeft.x += size.x;
            uvs.Add(bottomLeft);

            bottomLeft.y -= size.y;
            uvs.Add(bottomLeft);
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Polygons
        /************************************************************************************************************************/

        /// <summary>
        /// Adds indices, vertices, normals, and UVs for a polygon on the XY plane with the specified parameters.
        /// </summary>
        public static void ShapeEquilateralPolygonXY(MeshBuilder builder, int subMesh, Vector3 center, int sides, float radius, Rect uvArea)
        {
            int indexCount = builder.Indices[subMesh].Count;
            for (int i = 0; i < sides - 2; i++)
            {
                builder.IndexTriangle(subMesh, indexCount, indexCount + i + 2, indexCount + i + 1);
            }

            float increment = Mathf.PI * 2 / sides;
            for (int i = 0; i < sides; i++)
            {
                float angle = i * increment;
                Vector3 offset = VectorXYFromAngle(angle, radius, 0);
                float u = offset.x.LinearRescale(-radius, radius, uvArea.xMin, uvArea.xMax);
                float v = offset.y.LinearRescale(-radius, radius, uvArea.yMin, uvArea.yMax);
                builder.Vertices.Add(center + offset);
                builder.Normals.Add(Vector3.back);
                builder.UVs.Add(new Vector2(u, v));
            }
        }

        /// <summary>
        /// Adds indices, vertices, normals, and UVs for a polygon on the XY plane with the specified parameters.
        /// </summary>
        public static void ShapeEquilateralPolygonXY(MeshBuilder builder, int subMesh, Vector3 center, int sides, float radius)
        {
            ShapeEquilateralPolygonXY(builder, subMesh, center, sides, radius, new Rect(0, 0, 1, 1));
        }

        /// <summary>
        /// Duplicates the vertex data of a polygon with the vertices offset by 'extrusion' and adds indices to join
        /// them as faces to the original vertices.
        /// </summary>
        public static void ExtrudePolygon(MeshBuilder builder, int subMesh, int firstVertex, int sides, Vector3 extrusion)
        {
            Vector3 faceNormal = builder.Normals[firstVertex];

            int previousIndex = sides - 1;
            for (int i = 0; i < sides; i++)
            {
                Vector3 normal = Vector3.Cross(builder.Vertices[previousIndex] - builder.Vertices[i], faceNormal);

                builder.Index2Triangles(subMesh);
                DuplicateVertex(builder, previousIndex, normal, Vector2.zero);
                DuplicateVertex(builder, i, normal, Vector2.right);
                DuplicateVertex(builder, i, extrusion, normal, Vector2.one);
                DuplicateVertex(builder, previousIndex, extrusion, normal, Vector2.up);

                previousIndex = i;
            }
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Rings
        /************************************************************************************************************************/

        /// <summary>
        /// Adds indices, vertices, and normals to form a ring on the XY plane with the specified parameters.
        /// </summary>
        public static void BuildRingXY(MeshBuilder builder, Vector3 center, int sides, float innerRadius, float outerRadius)
        {
            float increment = Mathf.PI * 2 / sides;
            float halfIncrement = increment * 0.5f;

            for (int i = 0; i < sides; i++)
            {
                float angle = i * increment;
                builder.Vertices.Add(VectorXYFromAngle(angle - halfIncrement, innerRadius, 0));
                builder.Vertices.Add(VectorXYFromAngle(angle, outerRadius, 0));
                builder.Normals.Add(Vector3.back);
                builder.Normals.Add(Vector3.back);

                int i2 = i * 2;
                builder.IndexTriangle(0, i2, i2 + 2, i2 + 1);
                builder.IndexTriangle(0, i2 + 2, i2 + 3, i2 + 1);
            }

            int indexCount = builder.Indices[0].Count;

            List<int> indices = builder.Indices[0];
            indices[indexCount - 5] -= sides * 2;
            indices[indexCount - 3] -= sides * 2;
            indices[indexCount - 2] -= sides * 2;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Planar maps the UV values for a range of vertices into the 'uvArea' based on their XY positions relative to 'vertexArea'.
        /// </summary>
        public static void PlanarMapXY(MeshBuilder builder, int start, int length, Rect vertexArea, Rect uvArea)
        {
            Vector2 scale = new Vector2(
                1 / (vertexArea.xMax - vertexArea.xMin) * (uvArea.xMax - uvArea.xMin),
                1 / (vertexArea.yMax - vertexArea.yMin) * (uvArea.yMax - uvArea.yMin));

            length += start;

            if (builder.UVs.Count < length)
                builder.UVs.SetCount(length);

            for (; start < length; start++)
            {
                Vector2 uv = builder.Vertices[start];
                uv.x = uvArea.xMin + (uv.x - vertexArea.xMin) * scale.x;
                uv.y = uvArea.yMin + (uv.y - vertexArea.yMin) * scale.y;
                builder.UVs[start] = uv;
            }
        }

        /// <summary>
        /// Planar maps the UV values for all vertices using their XY positions.
        /// </summary>
        public static void PlanarMapXY(MeshBuilder builder)
        {
            Rect vertexArea = new Rect(builder.Vertices[0].x, builder.Vertices[0].y, 0, 0);
            for (int i = 1; i < builder.VertexCount; i++)
            {
                Vector3 vertex = builder.Vertices[i];

                if (vertex.x < vertexArea.xMin) vertexArea.xMin = vertex.x;
                else if (vertex.x > vertexArea.xMax) vertexArea.xMax = vertex.x;

                if (vertex.y < vertexArea.yMin) vertexArea.yMin = vertex.y;
                else if (vertex.y > vertexArea.yMax) vertexArea.yMax = vertex.y;
            }

            PlanarMapXY(builder, 0, builder.VertexCount, vertexArea, new Rect(0, 0, 1, 1));
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Utils
        /************************************************************************************************************************/

        /// <summary>
        /// Adds members to the list (or removes them) until the count reaches the specified value.
        /// </summary>
        public static void SetCount<T>(this List<T> list, int count) where T : new()
        {
            if (count > list.Count)
            {
                do
                {
                    list.Add(new T());
                }
                while (count > list.Count);
            }
            else if (count < list.Count)
            {
                list.RemoveRange(count, list.Count - count);
            }
        }

        /************************************************************************************************************************/

        /// <summary>Generates a vector with the specified z value and length in the specified direction on the XY axis.</summary>
        public static Vector3 VectorXYFromAngle(float radians, float length = 1, float z = 0)
        {
            return new Vector3(Mathf.Cos(radians) * length, Mathf.Sin(radians) * length, z);
        }

        /************************************************************************************************************************/

        /// <param name="builder">The <see cref="MeshBuilder"/> to get the UV channel from.</param>
        /// <param name="channel">The channel number (must be 1, 2, 3, or 4).</param>
        public static List<Vector4> GetUVs(MeshBuilder builder, int channel)
        {
            switch (channel)
            {
                case 1: return builder.UVs;
                case 2: return builder.UVs2;
                case 3: return builder.UVs3;
                case 4: return builder.UVs4;
                default:
                    throw new System.ArgumentException(
                        "MeshBuilderUtils.GetUvChannel only supports values of 1, 2, 3, and 4 since those are the only UV channels supported by the Mesh class");
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Doesn't take into account vertices that are shared by multiple triangles.
        /// Only the last triangle to include each vertex will determine its normal.
        /// </summary>
        public static void CalculateNormals(MeshBuilder builder, int subMesh, int minIndex, int maxIndex)
        {
            builder.Normals.Capacity = builder.Vertices.Capacity;

            List<int> subMeshIndices = builder.Indices[subMesh];
            for (int i = 0; i < subMeshIndices.Count; i += 3)
            {
                int index0 = subMeshIndices[i];
                if (index0 >= minIndex && index0 < maxIndex)
                {
                    // Get the three indices that make the triangle.
                    int
                        index1 = subMeshIndices[i + 1],
                        index2 = subMeshIndices[i + 2];

                    // Get the three vertices that make the triangle.
                    Vector3
                        point1 = builder.Vertices[index0],
                        point2 = builder.Vertices[index1],
                        point3 = builder.Vertices[index2];

                    // Get the lines connecting those points.
                    Vector3
                        line1 = point2 - point1,
                        line2 = point3 - point1;

                    // Use those lines to calculate the normal.
                    Vector3 normal = Vector3.Cross(line1, line2);
                    normal.Normalize();

                    // Assign the normal to all 3 vertices of the triangle.
                    builder.Normals[index0] = normal;
                    builder.Normals[index1] = normal;
                    builder.Normals[index2] = normal;
                }
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Doesn't work properly.
        /// TODO: Try: http://answers.unity3d.com/questions/7789/calculating-tangents-vector4.html
        /// </summary>
        public static void CalculateMeshTangents(Mesh mesh)
        {
            //speed up math by copying the mesh arrays
            int[] triangles = mesh.triangles;
            Vector3[] vertices = mesh.vertices;
            Vector2[] uv = mesh.uv;
            Vector3[] normals = mesh.normals;

            //variable definitions
            int triangleCount = triangles.Length;
            int vertexCount = vertices.Length;

            Vector3[] tan1 = new Vector3[vertexCount];
            Vector3[] tan2 = new Vector3[vertexCount];

            Vector4[] tangents = new Vector4[vertexCount];

            for (long a = 0; a < triangleCount; a += 3)
            {
                long i1 = triangles[a + 0];
                long i2 = triangles[a + 1];
                long i3 = triangles[a + 2];

                Vector3 v1 = vertices[i1];
                Vector3 v2 = vertices[i2];
                Vector3 v3 = vertices[i3];

                Vector2 w1 = uv[i1];
                Vector2 w2 = uv[i2];
                Vector2 w3 = uv[i3];

                float x1 = v2.x - v1.x;
                float x2 = v3.x - v1.x;
                float y1 = v2.y - v1.y;
                float y2 = v3.y - v1.y;
                float z1 = v2.z - v1.z;
                float z2 = v3.z - v1.z;

                float s1 = w2.x - w1.x;
                float s2 = w3.x - w1.x;
                float t1 = w2.y - w1.y;
                float t2 = w3.y - w1.y;

                float div = s1 * t2 - s2 * t1;
                float r = div == 0.0f ? 0.0f : 1.0f / div;
                //float r = 1.0f / (s1 * t2 - s2 * t1);

                Vector3 sdir = new Vector3((t2 * x1 - t1 * x2) * r, (t2 * y1 - t1 * y2) * r, (t2 * z1 - t1 * z2) * r);
                Vector3 tdir = new Vector3((s1 * x2 - s2 * x1) * r, (s1 * y2 - s2 * y1) * r, (s1 * z2 - s2 * z1) * r);

                tan1[i1] += sdir;
                tan1[i2] += sdir;
                tan1[i3] += sdir;

                tan2[i1] += tdir;
                tan2[i2] += tdir;
                tan2[i3] += tdir;
            }


            for (long a = 0; a < vertexCount; ++a)
            {
                Vector3 n = normals[a];
                Vector3 t = tan1[a];

                //Vector3 tmp = (t - n * Vector3.Dot(n, t)).normalized;
                //tangents[a] = new Vector4(tmp.x, tmp.y, tmp.z);
                Vector3.OrthoNormalize(ref n, ref t);
                tangents[a].x = t.x;
                tangents[a].y = t.y;
                tangents[a].z = t.z;

                tangents[a].w = (Vector3.Dot(Vector3.Cross(n, t), tan2[a]) < 0.0f) ? -1.0f : 1.0f;
            }

            mesh.tangents = tangents;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
    }
}