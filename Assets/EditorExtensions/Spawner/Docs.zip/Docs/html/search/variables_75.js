var searchData=
[
  ['unitlevel',['unitLevel',['../class_spawner.html#abd0e8aafcec41053c1cb11f8d720cbcd',1,'Spawner']]],
  ['unitlist',['unitList',['../class_spawner.html#adb45bd97779e885f6eddf3a940fface6',1,'Spawner']]]
];
